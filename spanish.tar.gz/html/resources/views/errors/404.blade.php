<!DOCTYPE html>
<html>
<head>
    <title>404 - Agave Rosa</title>    
    <link rel="stylesheet" type="text/css" href="{{ url('css/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ url('css/font-awesome.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ url('css/style.css') }}">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800">
    <style type="text/css">
        .page-404 {
            text-align: center;
            font-family: "Open Sans";
            margin: 40px 0;
        }
        .page-404 .cover {
            padding-top: 5%;
            margin-bottom: 30px;
        }
        .page-404 .cover h1 {
            color: #4a89dc;
            font-weight: 800;
            font-size: 140px;
            line-height: 120px;
        }
        .page-404 .navigation a {
            font-size: 24px;
        }
    </style>
</head>
<body class="page-404">

<div class="cover">
    <h1>404!</h1>
    <h3>Page Not Found.</h3>
</div>
<div class="navigation">
    <a class="btn btn-default" href="{{ URL::previous() }}"><i class="fa fa-arrow-left"></i> Back</a>
    <a class="btn btn-default" href="{{ url('') }}"><i class="fa fa-home"></i> Goto Home</a>
</div>

</body>
</html>