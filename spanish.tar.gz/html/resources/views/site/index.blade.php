@extends('layouts.site')

@push('stylesheet')
@endpush

@section('content')

<div class="container-fluid search-focus index-page">

    @if (Session::has('error-alert'))
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
    </div>
    @elseif (Session::has('success-alert'))
    <div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
    </div>
    @endif
    
    <div class="product-grid row">

        @foreach ($product_array as $product)
        @php ($product_link = url('category/' . DB::table('catalog_categories')->where('id', DB::table('catalog_product_categories')->where('product_id', $product->id)->first()->category_id)->first()->permalink . '/product/' . $product->permalink))
        @if ($product->type == '1')
        @php ($simple_product = $mycatalog->get_simple_product($product->id))
        <div class="grid-item col-lg-15 col-md-3 col-sm-4 col-xs-6">
            <div class="product">
                <a href="{{ $product_link }}" title="{{ $product->title }}">
                    <div class="image">
                        <img src="{{ url('storage/uploads/products/medium-image/' . $simple_product->image_path) }}" alt="img" class="img-responsive"/>
                    </div>
                    <div class="title">
                        <h4>{{ $product->title }}</h4>
                    </div>
                    <div class="price">{!! $mycatalog->get_simple_product_price($product->id) !!}</div>
                </a>
                @php ($catalog_product = $mycatalog->grid_rating($product->id))
                @include('site.shared.product-rating')
                <div class="wishlist pull-right">
                    <a class="add-to-wishlist-heart @if ($mycatalog->is_product_in_wishlist($product->id) == '1') active @endif" href="{{ url('customer/wishlist/product/' . $product->id) }}">
                        <i class="glyphicon glyphicon-heart"></i>
                    </a>
                </div>
            </div>
        </div>
        @elseif ($product->type == '2')
        @php ($associated_product = $mycatalog->get_configurable_product($product->id))
        @if ($associated_product)
        <div class="grid-item col-lg-15 col-md-3 col-sm-4 col-xs-6">
            <div class="product">
                <a href="{{ $product_link }}" title="{{ $product->title }}">
                    <div class="image">
                        <img src="{{ url('storage/uploads/products/medium-image/' . $associated_product->image_path) }}" alt="img" class="img-responsive"/>
                    </div>
                    <div class="title">
                        <h4>{{ $product->title }}</h4>
                    </div>
                    <div class="price">{!! $mycatalog->get_configurable_product_associated_product_price($product->id) !!}</div>
                </a>
                @php ($catalog_product = $mycatalog->grid_rating($product->id))
                @include('site.shared.product-rating')
                <div class="wishlist pull-right">
                    <a class="add-to-wishlist-heart @if ($mycatalog->is_product_in_wishlist($product->id) == '1') active @endif" href="{{ url('customer/wishlist/product/' . $product->id) }}">
                        <i class="glyphicon glyphicon-heart"></i>
                    </a>
                </div>
            </div>
        </div>
        @endif
        @endif
        @endforeach

    </div>
</div>
@endsection

@push('javascript')
@endpush
