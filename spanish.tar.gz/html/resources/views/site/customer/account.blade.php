@extends('layouts.site')

@push('stylesheet')
@endpush

@section('content')
<div class="container-fluid search-focus login-page">
    <h1 class="section-title"><span><i class="glyphicon glyphicon-user"></i> Account</span></h1>
    <ul class="breadcrumb">
        <li><a href="{{ url('') }}"><i class="fa fa-home"></i></a></li>
        <li class="active">Account</li>
    </ul>

    <div class="inner-page">

        @if (Session::has('error-alert'))
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
        </div>
        @elseif (Session::has('success-alert'))
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
        </div>
        @endif

        <div class="row">
            <div class="col-md-9">
                <div class="well bg-white">
                    <h2>Account History</h2>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <th class="text-center">ID</th>
                                <th>Products</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                @php ($checkout_array = DB::table('checkouts')->where('user_id', $mycustomer->get_user_id())->orderBy('id', 'DESC')->take(15))
                                @if ($checkout_array->count() != '0')
                                @foreach ($checkout_array->get() as $checkout)
                                <tr>
                                    <td class="text-center">{{ $checkout->id }}</td>
                                    <td>
                                        <ul>
                                            @foreach (DB::table('checkout_products')->where('user_id', $mycustomer->get_user_id())->where('checkout_id', $checkout->id)->get() as $checkout_product)
                                            <li>{{ DB::table('catalog_products')->where('id', $checkout_product->product_id)->first()->title }} [x {{ $checkout_product->qty }}] - {{ DB::table('catalog_attribute_options')->where('id', $checkout_product->color)->first()->store_value }}, {{ DB::table('catalog_attribute_options')->where('id', $checkout_product->size)->first()->store_value }} = ${{ number_format($checkout_product->sub_total, 2) }}</li>
                                            @endforeach
                                        </ul>
                                    </td>
                                    <td>${{ number_format($checkout->total_payment, 2) }}</td>
                                    <td>{!! $myfunction->checkout_status($checkout->status) !!}</td>
                                    <td>{{ date('Y-m-d', strtotime($checkout->created_at)) }}</td>
                                    <td>
                                    @if ( $checkout->status == '0')
                                        <a class="btn btn-primary btn-sm" href="{{ url('cart/checkout-repay/' . $checkout->id . '/' . $checkout->key) }}"><i class="fa fa-shopping-cart"></i> Checkout</a>
                                        <a class="btn btn-danger btn-sm btn-cancel" href="{{ url('customer/account/cancel-order/' . $checkout->id) }}"><i class="fa fa-close"></i> Cancle</a>
                                    @endif
                                    </td>
                                </tr>
                                @endforeach
                                @else
                                <tr>
                                    <td colspan="6">
                                        <div class="well text-center">Nothing here</div>
                                    </td>
                                </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                @php ($customer = DB::table('customers')->where('user_id', $mycustomer->get_user_id())->first())
                <div class="well bg-white">
                    <form action="{{ url('customer/account/process') }}" method="post">
                        {{ csrf_field() }}
                        <h2>Account Information</h2>
                        <label for="inputFirstname">Firstname</label>
                        <input id="inputFirstname" class="form-control" type="text" name="firstname" value="{{ $customer->firstname }}">
                        <br>
                        <label for="Lastname">Lastname</label>
                        <input id="Lastname" class="form-control" type="text" name="lastname" value="{{ $customer->lastname }}">
                        <br>
                        <label for="Phone">Phone</label>
                        <input id="Phone" class="form-control" type="number" name="phone" value="{{ $customer->phone }}">
                        <br>
                        <label for="Email">Email</label>
                        <input id="Email" class="form-control" type="text" name="email" disabled="disabled" value="{{ $customer->email }}">
                        <br>
                        <input class="btn btn-primary" type="submit" name="submit" value="Save">
                    </form>
                </div>
                <div class="well bg-white">
                    <form action="{{ url('customer/account/change-password') }}" method="post">
                        {{ csrf_field() }}
                        <h2>Login Information</h2>
                        <label for="OldPassword">Old Password</label>
                        <input id="OldPassword" class="form-control" type="password" name="old-password">
                        <br>
                        <label for="NewPassword">New Password</label>
                        <input id="NewPassword" class="form-control" type="password" name="new-password">
                        <br>
                        <label for="VerifyPassword">Verify Password</label>
                        <input id="VerifyPassword" class="form-control" type="password" name="verify-password">
                        <br>
                        <input class="btn btn-primary" type="submit" name="submit" value="Change Password">
                    </form>
                </div>
            </div>
        </div>


    </div>
</div>
@endsection

@push('javascript')
<script type="text/javascript">
    jQuery(document).ready(function() {

        $('.btn-cancel').click(function () {
            var x;
            if (confirm("Are you sure? you want to Cancel Order? This couldn't undo.") == true) {

            } else {
                return false;
            }
        });

    });
</script>
@endpush
