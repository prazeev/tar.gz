@extends('layouts.site')

@push('stylesheet')
@endpush

@section('content')
<div class="container-fluid search-focus forgot-password-page">
    <h1 class="section-title">
        <span>Did you forgot password?</span>
        <a class="btn btn-link pull-right btn-lg" href="{{ url('customer/login') }}"><span class="fa fa-arrow-circle-left"></span> Back</a>
    </h1>
    <ul class="breadcrumb">
        <li><a href="{{ url('') }}"><i class="fa fa-home"></i></a></li>
        <li><a href="{{ url('customer') }}">Customer</a></li>
        <li class="active">Forgot password</li>
    </ul>
    <div class="inner-page">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="well bg-white">
                <h2 class="border-bottom">Account details</h2>
                <form action="{{ url('customer/forgot-password') }}" method="post">
                    {{ csrf_field() }}
                    @if (Session::has('error-alert'))
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
                    </div>
                    @elseif (Session::has('success-alert'))
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
                    </div>
                    @endif
                    <div class="form-group">
                        <label for="inputEmail">Email Address</label>
                        <input type="email" class="form-control" name="email" id="inputEmail" required="required">
                    </div>
                    <input class="btn btn-default btn-lg" type="submit" name="submit" value="Submit">
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('javascript')
@endpush
