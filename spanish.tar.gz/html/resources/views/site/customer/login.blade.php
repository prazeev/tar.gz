@extends('layouts.site')

@push('stylesheet')
@endpush

@section('content')
<div class="container-fluid search-focus login-page">
    <h1 class="section-title"><span>Login or Create new Account</span></h1>
    <ul class="breadcrumb">
        <li><a href="{{ url('') }}"><i class="fa fa-home"></i></a></li>
        <li class="active">Login</li>
    </ul>
    <div class="inner-page">
        <div class="row">
            <div class="col-md-6">
                <div class="well bg-white">
                    <h2>New Customers</h2>
                    <p>By creating an account with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
                    <p><a class="btn btn-default btn-lg" href="{{ url('customer/register') }}">Create new Account</a></p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="well bg-white">
                    <h2 class="border-bottom">Registered Customers</h2>
                    <p>If you have an account with us, please log in.</p>
                    <form action="{{ url('customer/login') }}" method="post">
                        {{ csrf_field() }}
                        @if (Session::has('error-alert'))
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
                        </div>
                        @elseif (Session::has('success-alert'))
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
                        </div>
                        @endif
                        <div class="form-group">
                            <label for="inputEmail">Email Address</label>
                            <input type="email" class="form-control" name="email" id="inputEmail">
                        </div>
                        <div class="form-group">
                            <label for="inputPassword">Password</label>
                            <input type="password" class="form-control" name="password" id="inputPassword">
                        </div>
                        <input class="btn btn-default btn-lg" type="submit" name="submit" value="Login"> <a href="{{ url('customer/forgot-password') }}" style="margin-left: 20px;">Forgot password?</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('javascript')
@endpush
