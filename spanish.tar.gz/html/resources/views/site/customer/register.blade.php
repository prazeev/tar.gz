@extends('layouts.site')

@push('stylesheet')
@endpush

@section('content')
<div class="container-fluid search-focus register-page">
    <h1 class="section-title">
        <span>Create new Account</span>
        <a class="btn btn-link pull-right btn-lg" href="{{ url('customer/login') }}"><span class="fa fa-arrow-circle-left"></span> Back</a>
    </h1>
    <ul class="breadcrumb">
        <li><a href="{{ url('') }}"><i class="fa fa-home"></i></a></li>
        <li><a href="{{ url('customer') }}">Customer</a></li>
        <li class="active">Register</li>
    </ul>
    <div class="inner-page">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
            <div class="well bg-white">
                <form action="{{ url('customer/register') }}" method="post">
                    {{ csrf_field() }}
                    @if (Session::has('error-alert'))
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
                    </div>
                    @elseif (Session::has('success-alert'))
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
                    </div>
                    @endif
                    <h2 class="border-bottom">Personal Information</h2>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label for="inputFirstname">Firstname</label>
                            <input type="text" class="form-control" name="firstname" id="inputFirstname" required="required">
                        </div>
                        <div class="col-md-6">
                            <label for="inputLastname">Lastname</label>
                            <input type="text" class="form-control" name="lastname" id="inputLastname" required="required">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPhoneNumber">Phone Number</label>
                        <input type="number" class="form-control" name="phone" id="inputPhoneNumber" required="required">
                    </div>
                    <div class="form-group">
                        <label for="inputEmail">Email Address</label>
                        <input type="email" class="form-control" name="email" id="inputEmail" required="required">
                    </div>
                    <h2 class="border-bottom">Login Information</h2>
                    <div class="form-group row">
                        <div class="col-md-6">
                            <label for="inputPassword">Password</label>
                            <input type="password" class="form-control" name="password" id="inputPassword" required="required">
                        </div>
                        <div class="col-md-6">
                            <label for="inputConfirmPassword">Confirm Password</label>
                            <input type="password" class="form-control" name="conform-password" id="inputConfirmPassword" required="required">
                        </div>
                    </div>
                    <input class="btn btn-default btn-lg" type="submit" name="submit" value="Register">
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('javascript')
@endpush
