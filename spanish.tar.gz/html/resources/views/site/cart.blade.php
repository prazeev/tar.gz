@extends('layouts.site')

@push('stylesheet')
<style>
    .swatche {
        height: 52px;
        width: 52px;
        padding: 2px;
        border: solid 1px #ccc;
    }
    table.checkout-total {
        border-radius: 0;
        font-size: 16px;
    }
    table.checkout-total tr td {
        padding: 15px;
    }
</style>
@endpush

@section('content')
<div class="container-fluid search-focus cart-page">
    <h1 class="section-title">
        <a class="pull-right btn btn-default" href="{{ url('cart/empty-cart') }}">Empty Cart</a>
        <span><i class="glyphicon glyphicon-shopping-cart"></i> Cart</span>
    </h1>
    <ul class="breadcrumb">
        <li><a href="{{ url('') }}"><i class="fa fa-home"></i></a></li>
        <li class="active">Cart</li>
    </ul>

    @if (Session::has('error-alert'))
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
    </div>
    @elseif (Session::has('success-alert'))
    <div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
    </div>
    @endif

    <div class="row">
        <div class="col-md-9">
            <div class="table-responsive">
                <table class="table table-bordered product-table">
                    <thead>
                        <tr class="active">
                            <th class="text-center" style="width: 120px;">Image</th>
                            <th>Product Title</th>
                            <th class="text-center">Color</th>
                            <th class="text-center">Size</th>
                            <th class="text-center">Qty</th>
                            <th class="text-center">Sub Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if (!is_array(session('shopping-cart')))
                        <tr>
                            <td colspan="6" class="well text-center">No product found. Add something now!</td>
                        </tr>
                        @else
                        @foreach (session('shopping-cart') as $cart_product)
                        @php ($product = DB::table('catalog_products')->where('id', $cart_product['product_id'])->first())
                        @php ($product_link = url('category/' . DB::table('catalog_categories')->where('id', DB::table('catalog_product_categories')->where('product_id', $product->id)->first()->category_id)->first()->permalink . '/product/' . $product->permalink))
                        <tr>
                            <td class="text-center">
                                @if ($product->type == '1')
                                @php ($simple_product = $mycatalog->get_simple_product($product->id))
                                <a href="{{ $product_link }}">
                                    <img src="{{ url('storage/uploads/products/small-image/' . $simple_product->image_path) }}" alt="img"/>
                                </a>
                                @elseif ($product->type == '2')
                                @php ($associated_product = $mycatalog->get_configurable_product($product->id))
                                <a href="{{ $product_link }}">
                                    <img src="{{ url('storage/uploads/products/small-image/' . $associated_product->image_path) }}" alt="img"/>
                                </a>
                                @endif
                            </td>
                            <td>
                                <a href="{{ $product_link }}"><h4>{{ $product->title }}</h4></a>
                            </td>
                            <td class="text-center"><img class="swatche" src="{{ url('storage/' . DB::table('catalog_attribute_options')->where('id', $cart_product['color'])->first()->swatche) }}"></td>
                            <td class="text-center"><img class="swatche" src="{{ url('storage/' . DB::table('catalog_attribute_options')->where('id', $cart_product['size'])->first()->swatche) }}"></td>
                            <td class="text-center">{{ $cart_product['qty'] }}</td>
                            <td class="text-center price">${{ number_format($cart_product['sub_total'], 2) }}</td>
                        </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
            </div>

        </div>
        <div class="col-md-3">
            @if ($mycustomer->has_customer() == '1')
            <a class="btn btn-default btn-lg btn-block" href="#" data-toggle="modal" data-target="#checkoutModal">Checkout <i class="fa fa-arrow-right"></i></a>
            @else
            <a class="btn btn-default btn-lg btn-block" href="{{ url('customer/login') }}">Login to Checkout <i class="fa fa-arrow-right"></i></a>
            @endif
            <br>
            <div class="panel panel-default">
                <table class="table checkout-total">
                    <tr>
                        <td>Total:</td>
                        <td class="text-right price">${{ number_format(session('shopping-cart-total'), 2) }}</td>
                    </tr>
                </table>
            </div>
            @if (!Session::has('shopping-cart-coupon') || session('shopping-cart-coupon') == '')
            <div class="panel panel-default">
            <form action="{{ url('cart/coupon') }}" method="post">
                {{ csrf_field() }}
                <div class="panel-heading">Have a Coupon code?</div>
                <table class="table">
                    <tr>
                        <td style="vertical-align: middle;">Code:</td>
                        <td><input class="form-control" type="text" name="coupon"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input class="btn btn-default pull-right" type="submit" value="Apply"></td>
                    </tr>
                </table>
                </form>
            </div>
            @else
            <div class="panel panel-default">
                <div class="panel-heading">Used Coupon: <code>{{ session('shopping-cart-coupon') }}</code></div>
            </div>
            @endif
        </div>
    </div>

</div>


@if ($mycustomer->has_customer() == '1')
@php ($user = DB::table('users')->where('id', $mycustomer->get_user_id())->first());
<div class="modal fade" id="checkoutModal" tabindex="-1" role="dialog" aria-labelledby="checkoutModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Checkout Information</h4>
            </div>
            <div class="modal-body">
                <form action="{{url('cart/checkout-process')}}" method="post">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label for="inputShippingName">Shipping Name</label>
                        <input type="text" class="form-control" name="shipping-name" id="inputShippingName" required="required" value="<?php echo $user->name; ?>">
                    </div>
                    <div class="form-group">
                        <label for="inputShippingAddress">Shipping Address</label>
                        <input type="text" class="form-control" name="shipping-address" id="inputShippingAddress" required="required">
                    </div>
                    <div class="form-group">
                        <label for="inputShippingAddress">Shipping Address Alternative</label>
                        <input type="text" class="form-control" name="shipping-address-alt" id="inputShippingAddressAlt">
                    </div>
                    <div class="form-group">
                        <label for="inputPostalCode">Shipping Postal Code</label>
                        <input type="text" class="form-control" name="shipping-postal-code" id="inputPostalCode" required="required">
                    </div>
                    <div class="form-group">
                        <label for="inputShippingPhoneNumber">Shipping Phone Number</label>
                        <input type="number" class="form-control" name="shipping-phone" id="inputShippingPhoneNumber" required="required">
                    </div>
                    <div class="form-group">
                        <label for="inputShippingEmail">Shipping Email Address</label>
                        <input type="email" class="form-control" name="shipping-email" id="inputShippingEmail" required="required" value="<?php echo $user->email; ?>">
                    </div>
                    <div class="form-group">
                        <label for="inputComment">Comment</label>
                        <textarea class="form-control" name="comment" id="inputComment" rows="4"></textarea>
                    </div>
                    <div class="text-center">
                        <input class="btn btn-primary btn-lg" type="submit" name="submit" value="Checkout">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endif

@endsection

@push('javascript')
@endpush
