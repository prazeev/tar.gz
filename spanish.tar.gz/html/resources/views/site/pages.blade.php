@extends('layouts.site')

@push('stylesheet')
@endpush

@section('content')
<div class="container-fluid search-focus page-{{ $page->permalink }}">
    <h1 class="section-title"><span>{{ $page->title }}</span></h1>
    <ul class="breadcrumb">
        <li><a href="{{ url('') }}"><i class="fa fa-home"></i></a></li>
        <li class="active">{{ $page->title }}</li>
    </ul>
    <div class="inner-page">
        <div class="well bg-white">
            {!! $page->content !!}
        </div>
    </div>
</div>
@endsection

@push('javascript')
@endpush
