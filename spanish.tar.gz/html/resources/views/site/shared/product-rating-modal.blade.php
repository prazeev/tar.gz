
@if (!$mycustomer->has_customer())
<!-- ratingModal -->
<div class="modal fade" id="ratingModal" tabindex="-1" role="dialog" aria-labelledby="ratingModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel"><span class="rating"></span></h4>
            </div>
            <div class="modal-body">
                You must login first to give a Rating & Review!
            </div>
            <div class="modal-footer">
                <a class="btn btn-primary" href="{{ url('customer/login') }}">Login</a>
            </div>
        </div>
    </div>
</div>
@elseif (DB::table('checkout_products')->join('checkouts', 'checkout_products.checkout_id', '=', 'checkouts.id')->where('checkout_products.product_id', $product->id)->where('checkout_products.user_id', $mycustomer->get_user_id())->where('checkouts.status', '90')->count() == '0')
<!-- ratingModal -->
<div class="modal fade" id="ratingModal" tabindex="-1" role="dialog" aria-labelledby="ratingModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel"><span class="rating"></span></h4>
            </div>
            <div class="modal-body">
                You should buy it first to give a Rating & Review!
            </div>
        </div>
    </div>
</div>
@elseif (DB::table('ratings')->where('ratingable_type', 'App\CatalogProducts')->where('ratingable_id', $product->id)->where('author_type', 'App\User')->where('author_id', $mycustomer->get_user_id())->count() == '0')
<!-- ratingModal -->
<div class="modal fade" id="ratingModal" tabindex="-1" role="dialog" aria-labelledby="ratingModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="{{ url('review/product/'.$product->id.'/process') }}" method="post">
                {{ csrf_field() }}
                <input type="hidden" name="rating">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel"><span class="rating"></span></h4>
                </div>
                <div class="modal-body">
                    <label>Review</label>
                    <textarea class="form-control" name="review" rows="6"></textarea>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
@else
@php ($review = DB::table('reviews')->where('user_id', $mycustomer->get_user_id())->where('product_id', $product->id)->first())
<!-- ratingModal -->
<div class="modal fade" id="ratingModal" tabindex="-1" role="dialog" aria-labelledby="ratingModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="{{ url('review/product/'.$product->id.'/edit-process') }}" method="post">
                {{ csrf_field() }}
                <input type="hidden" name="rating">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel"><span class="rating"></span></h4>
                </div>
                <div class="modal-body">
                    <label>Review</label>
                    <textarea class="form-control" name="review" rows="6">{{ $review->review }}</textarea>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endif