<span class="rating">
    @if (isset($catalog_product))
    @php ($averageRating = json_decode($catalog_product->averageRating()))
    @php ($averageRating = ceil($averageRating[0]))
    @if ($averageRating)
    @for ($i = '1'; $i < $averageRating + 1; $i++)
    <i class="fa fa-star active"></i>
    @endfor
    @for ($i = $averageRating + 1; $i <= 5; $i++)
    <i class="fa fa-star"></i>
    @endfor
    @else
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    <i class="fa fa-star"></i>
    @endif

    @else
    @php ($averageRating = json_decode($product->averageRating()))
    @php ($averageRating = ceil($averageRating[0]))
    @if ($averageRating)
    @for ($i = '1'; $i < $averageRating + 1; $i++)
    <a href="#" data-rating-value="{{ $i }}" data-toggle="modal" data-target="#ratingModal"><i class="fa fa-star active"></i></a>
    @endfor
    @for ($i = $averageRating + 1; $i <= 5; $i++)
    <a href="#" data-rating-value="{{ $i }}" data-toggle="modal" data-target="#ratingModal"><i class="fa fa-star"></i></a>
    @endfor
    @else
    <a href="#" data-rating-value="1" data-toggle="modal" data-target="#ratingModal"><i class="fa fa-star"></i></a>
    <a href="#" data-rating-value="2" data-toggle="modal" data-target="#ratingModal"><i class="fa fa-star"></i></a>
    <a href="#" data-rating-value="3" data-toggle="modal" data-target="#ratingModal"><i class="fa fa-star"></i></a>
    <a href="#" data-rating-value="4" data-toggle="modal" data-target="#ratingModal"><i class="fa fa-star"></i></a>
    <a href="#" data-rating-value="5" data-toggle="modal" data-target="#ratingModal"><i class="fa fa-star"></i></a>
    @endif
    
    @endif
    
</span>