@php ($rating = DB::table('ratings')->where('ratingable_type', 'App\CatalogProducts')->where('ratingable_id', $product->id)->where('author_id', $mycustomer->get_user_id())->first())
@php ($user = DB::table('users')->where('id', $mycustomer->get_user_id())->first())
@php ($review = DB::table('reviews')->where('user_id', $mycustomer->get_user_id())->where('product_id', $product->id)->first())
<div class="well">
    <div class="row">
        <div class="col-md-4 text-right">
            <div class="user-name">{{ $user->name }}</div>
            <span class="rating">
            @for ($i = '1'; $i < $rating->rating + 1; $i++)
            <i class="fa fa-star active"></i>
            @endfor
            @for ($i = $rating->rating + 1; $i <= 5; $i++)
            <i class="fa fa-star"></i>
            @endfor
        </span>
    </div>
    <div class="col-md-8 review-text">
        {{ $review->review }}
    </div>
</div>
</div>