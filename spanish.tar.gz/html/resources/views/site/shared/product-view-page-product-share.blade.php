<h4>Share</h4>
<div class="social-icon">
    <a class="facebook" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u={{ url()->current() }}"><i class="fa fa-facebook fa-fw"></i></a>
    <a class="twitter" target="_blank" href="https://twitter.com/home?status={{ url()->current() }}"><i class="fa fa-twitter fa-fw"></i></a>
    <a class="google-plus" target="_blank" href="https://plus.google.com/share?url={{ url()->current() }}"><i class="fa fa-google-plus fa-fw"></i></a>
</div>