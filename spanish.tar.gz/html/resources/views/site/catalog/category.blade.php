@extends('layouts.site')

@push('stylesheet')
@endpush

@section('content')
<div class="container-fluid search-focus category-page">
    <h1 class="section-title">Category: <span>{{ $category->title }}</span></h1>
    <ul class="breadcrumb">
        <li><a href="{{ url('') }}"><i class="fa fa-home"></i></a></li>
        <li class="active">{{ $category->title }}</li>
    </ul>
    <div class="product-grid row">



        @foreach ($product_array as $product)
        @php ($product_link = url('category/' . $category->permalink . '/product/' . $product->permalink))
        @if ($product->type == '1')
        @php ($simple_product = $mycatalog->get_simple_product($product->id))
        <div class="grid-item col-lg-15 col-md-3 col-sm-4 col-xs-6">
            <div class="product">
                <a href="{{ $product_link }}" title="{{ $product->title }}">
                    <div class="image">
                        <img src="{{ url('storage/uploads/products/medium-image/' . $simple_product->image_path) }}" alt="img" class="img-responsive"/>
                    </div>
                    <div class="title">
                        <h4>{{ $product->title }}</h4>
                    </div>
                    <div class="price">{!! $mycatalog->get_simple_product_price($product->id) !!}</div>
                </a>
                @php ($catalog_product = $mycatalog->grid_rating($product->id))
                @include('site.shared.product-rating')
                <div class="wishlist pull-right">
                    <a class="add-to-wishlist-heart @if ($mycatalog->is_product_in_wishlist($product->id) == '1') active @endif" href="{{ url('customer/wishlist/product/' . $product->id) }}">
                        <i class="glyphicon glyphicon-heart"></i>
                    </a>
                </div>
            </div>
        </div>
        @elseif ($product->type == '2')
        @php ($associated_product = $mycatalog->get_configurable_product($product->id))
        @if ($associated_product)
        <div class="grid-item col-lg-15 col-md-3 col-sm-4 col-xs-6">
            <div class="product">
                <a href="{{ $product_link }}" title="{{ $product->title }}">
                    <div class="image">
                        <img src="{{ url('storage/uploads/products/medium-image/' . $associated_product->image_path) }}" alt="img" class="img-responsive"/>
                    </div>
                    <div class="title">
                        <h4>{{ $product->title }}</h4>
                    </div>
                    <div class="price">{!! $mycatalog->get_configurable_product_associated_product_price($product->id) !!}</div>
                </a>
                @php ($catalog_product = $mycatalog->grid_rating($product->id))
                @include('site.shared.product-rating')
                <div class="wishlist pull-right">
                    <a class="add-to-wishlist-heart @if ($mycatalog->is_product_in_wishlist($product->id) == '1') active @endif" href="{{ url('customer/wishlist/product/' . $product->id) }}">
                        <i class="glyphicon glyphicon-heart"></i>
                    </a>
                </div>
            </div>
        </div>
        @endif
        @endif
        @endforeach

    </div>
</div>
@endsection

@push('javascript')
@endpush
