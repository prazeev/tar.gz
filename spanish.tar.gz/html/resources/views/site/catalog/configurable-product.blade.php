@extends('layouts.site')

@push('stylesheet')
@endpush

@section('content')
<div class="container search-focus configurable-product-page ">
    <ul class="breadcrumb">
        <li><a href="{{ url('') }}"><i class="fa fa-home"></i></a></li>
        <li><a href="{{ url('category/' . $category->permalink) }}">{{ $category->title }}</a></li>
        <li class="active">{{ $product->title }}</li>
    </ul>
    <div class="inner-page product-view-page">
        <div class="row">
            <div class="col-md-5 product-image">

                @php ($default_image = DB::table('catalog_product_images')->where('product_id', $product->id)->where('associated_product_id', $associated_product->id)->where('image_default', '1')->first())
                <div class="image-viewer text-center">
                    <img id="zoom_09" class="visible-lg visible-md" src="{{ url('storage/uploads/products/large-image/' . $default_image->image_path) }}" data-zoom-image="{{ url('storage/uploads/products/' . $default_image->image_path) }}"/>
                    <img class="hidden-lg hidden-md" src="{{ url('storage/uploads/products/large-image/' . $default_image->image_path) }}" data-zoom-image="{{ url('storage/uploads/products/' . $default_image->image_path) }}"/>
                </div>
                <div class="image-grid">
                    @foreach (DB::table('catalog_product_images')->where('product_id', $product->id)->where('associated_product_id', $associated_product->id)->orderBy('image_order')->get() as $image)
                    <a class="btn-change-image-viewer" href="#" data-image="{{ url('storage/uploads/products/large-image/' . $image->image_path) }}" data-zoom-image="{{ url('storage/uploads/products/' . $image->image_path) }}">
                        <img id="img_01" src="{{ url('storage/uploads/products/small-image/' . $image->image_path) }}" />
                    </a>
                    @endforeach
                </div>
            </div>
            <div class="col-md-7 product-details">
                <form action="{{ Request::fullUrl() }}" method="post">
                    {{ csrf_field() }}
                    @if (Session::has('error-alert'))
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
                    </div>
                    @elseif (Session::has('success-alert'))
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
                    </div>
                    @endif
                    <div class="product-title">
                        <a class="add-to-wishlist pull-right @if ($mycatalog->is_product_in_wishlist($product->id) == '1') active @endif" href="{{ url('customer/wishlist/product/' . $product->id) }}">
                            <i class="glyphicon glyphicon-heart"></i>
                        </a>
                        <h1>{{ $product->title }}</h1>
                    </div>
                    <div class="product-tagline">
                        <p>{!! nl2br($product->tagline) !!}</p>
                    </div>
                    <div class="product-price product-stock">
                        <span class="stock pull-right">Stock: {{ $mycatalog->get_configurable_product_stock($product->id, $associated_product->id) }}</span>
                        {!! $mycatalog->get_configurable_product_price($product->id, $associated_product->id) !!}
                    </div>
                    <div class="product-color product-size">
                        <h4>Color</h4>
                        @php ($attribute_color_id = $mycatalog->get_attribute_id('Color'))
                        @php ($attribute_size_id = $mycatalog->get_attribute_id('Size'))
                        @if (DB::table('catalog_attributes')->where('title', 'Color')->first()->swatches == '1')
                        <div class="swatches">
                            <input class="input-cart-color" type="hidden" value="{{ $default_color_option_id }}">
                            @foreach (DB::table('catalog_product_attributes')->where('product_id', $product->id)->where('attribute_id', $attribute_color_id)->groupBy('attribute_option_id')->orderBy('id')->get() as $swatche)
                            <a href="{{ Request::url() . '?color=' . $swatche->attribute_option_id }}"><img class="swatche @if ($default_color_option_id == $swatche->attribute_option_id) active @endif" src="{{ url('storage/' . DB::table('catalog_attribute_options')->where('attribute_id', $attribute_color_id)->where('id', $swatche->attribute_option_id)->first()->swatche) }}"></a>
                            @endforeach
                        </div>
                        @endif
                        <h4>Size</h4>
                        @if (DB::table('catalog_attributes')->where('title', 'Size')->first()->swatches == '1')
                        <div class="swatches">
                            <input class="input-cart-size" type="hidden" value="{{ $default_size_option_id }}">
                            @foreach ($associated_product_for_size as $row)
                            @php ($swatche = DB::table('catalog_product_attributes')->where('product_id', $product->id)->where('associated_product_id', $row)->where('attribute_id', $attribute_size_id)->first())
                            <a href="{{ Request::url() . '?color=' . $default_color_option_id . '&size=' . $swatche->attribute_option_id }}"><img class="swatche @if ($default_size_option_id == $swatche->attribute_option_id) active @endif" src="{{ url('storage/' . DB::table('catalog_attribute_options')->where('attribute_id', $attribute_size_id)->where('id', $swatche->attribute_option_id)->first()->swatche) }}" data-option-id="{{ $swatche->attribute_option_id }}"></a>
                            @endforeach
                        </div>
                        @endif
                    </div>
                    <div class="add-to-cart">
                        Qty: <input class="qty input-cart-qty" type="number" name="qty" value="1" min="1" max="99">
                        <input class="btn btn-primary" type="submit" name="submit" value="Add to Cart">
                        @include('site.shared.product-rating')
                    </div>
                    <div class="product-share">
                        @include('site.shared.product-view-page-product-share')
                    </div>
                </form>
            </div>
        </div>

        <div class="product-tabs">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#description" aria-controls="description" role="tab" data-toggle="tab">Description</a></li>
                <li role="presentation"><a href="#review" aria-controls="review" role="tab" data-toggle="tab">Review</a></li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active" id="description">{!! nl2br($product->description) !!}</div>
                <div role="tabpanel" class="tab-pane fade review" id="review">
                    @php ($rating_array = DB::table('ratings')->where('ratingable_type', 'App\CatalogProducts')->where('ratingable_id', $product->id)->where('author_id', '!=', $mycustomer->get_user_id()))
                    @if ($rating_array->count() >= '1')
                    @if (DB::table('ratings')->where('ratingable_type', 'App\CatalogProducts')->where('ratingable_id', $product->id)->where('author_id', $mycustomer->get_user_id())->count())
                    <div class="well text-center">
                        <span class="title">Update your rating & review:</span> @include('site.shared.product-rating')
                    </div>
                    @include('site.shared.product-rating-user')
                    @else
                    <div class="well text-center">
                        <span class="title">Leave your rating & review:</span> @include('site.shared.product-rating')
                    </div>
                    @endif
                    <div class="row review-grid"> 
                        @foreach ($rating_array->get() as $rating)
                        @php ($rating_user = DB::table('users')->where('id', $rating->author_id)->first())
                        @php ($review = DB::table('reviews')->where('rating_id', $rating->id)->where('user_id', $rating_user->id)->where('product_id', $product->id)->first())
                        <div class="col-md-6 grid-item">
                            <div class="well">
                                <div class="row">
                                    <div class="col-md-4 text-right">
                                        <div class="user-name">{{ $rating_user->name }}</div>
                                        <span class="rating">
                                            @for ($i = '1'; $i < $rating->rating + 1; $i++)
                                            <i class="fa fa-star active"></i>
                                            @endfor
                                            @for ($i = $rating->rating + 1; $i <= 5; $i++)
                                            <i class="fa fa-star"></i>
                                            @endfor
                                        </span>
                                    </div>
                                    <div class="col-md-8 review-text">
                                        {{ $review->review }}
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                    @else
                    @if (DB::table('ratings')->where('ratingable_type', 'App\CatalogProducts')->where('ratingable_id', $product->id)->where('author_id', $mycustomer->get_user_id())->count())
                    @include('site.shared.product-rating-user')
                    <div class="well text-center">
                        <p>No other reviews found.</p>
                    </div>
                    @else
                    <div class="well text-center">
                        @include('site.shared.product-rating')
                        <p>No reviews found. Be first to give a review.</p>
                    </div>
                    @endif
                    @endif
                </div>
            </div>

        </div>
    </div>

    @include('site.shared.product-view-page-related-products')

</div>

@include('site.shared.product-rating-modal')

@endsection

@push('javascript')
<script src="{{ url('js/jquery.elevateZoom-3.0.8.min.js') }}"></script>
<script>
    $(document).ready(function() {

        $("#zoom_09").elevateZoom({
            gallery : "gallery_09",
            galleryActiveClass: "active",
            zoomWindowFadeIn: 500,
            zoomWindowFadeOut: 500,
            lensFadeIn: 500,
            lensFadeOut: 500,
            easing : true,
        });

        $('.btn-change-image-viewer').bind('click', function(e) {
            var smallImage = $(this).attr('data-image');
            var largeImage = $(this).attr('data-zoom-image');
            $('.btn-change-image-viewer').removeClass('active');
            $(this).addClass('active');
            $(".image-viewer img").attr('src', smallImage).removeAttr('data-zoom-image').attr('data-zoom-image', largeImage);
            $('.image-viewer img').data('elevateZoom').swaptheimage(smallImage, largeImage);
            return false;
        });
        $('.rating a').hover(function() {
            $(this).children('.fa').addClass('hover');
            $(this).prevAll().children('.fa').addClass('hover');
            $(this).nextAll().children('.fa').addClass('dark');
        }, function() {
            $(this).children('.fa').removeClass('hover');
            $(this).prevAll().children('.fa').removeClass('hover');
            $(this).nextAll().children('.fa').removeClass('dark');
        });
        $('.rating a').click(function(event) {
            event.preventDefault();
            var rating_value = $(this).data('rating-value');

            $('#ratingModal [name="rating"]').val(rating_value);
            $('#ratingModal .rating').html('');
            for (var i = 0; i < rating_value; i++) {
                $('#ratingModal .rating').append('<i class="fa fa-star active"></i>');
            }

        });
        $('#ratingModal').on('hidden.bs.modal', function () {
            $('.rating a .fa').removeClass('click');
        })
        $('href="#review"').click(function(event) {

            var $review_grid = $('.review-grid').masonry({
                itemSelector: '.grid-item',
                percentPosition: true
            });
            $review_grid.imagesLoaded().progress( function() {
                $review_grid.masonry('layout');
            });
        });
    });
</script>
@endpush
