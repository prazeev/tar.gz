<!DOCTYPE html>
<html prefix="og: http://ogp.me/ns#" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@if (isset($page_title)) {{ $page_title }} - Agave Rosa @elseif (isset($give_title)) {{ $give_title }} @else Agave Rosa @endif</title>
    @if (isset($seo_title))
    <meta property="og:title" content="{{ $seo_title }}" />
    @endif
    @if (isset($seo_keywords))
    <meta name="keywords" content="{{ $seo_keywords }}" />
    @endif
    @if (isset($seo_description))
    <meta name="author" content="{{ $seo_description }}" />
    <meta property="og:description" content="{{ $seo_description }}" />
    @endif
    @if (isset($seo_image))
    <meta property="og:image" content="{{ $seo_image }}" />
    @endif
    <meta property="og:url" content="{{ url()->current() }}" />
    <link rel="shortcut icon" href="{{ url('images/favicon.png') }}"/>

    {{-- Load CSS files --}}
    <link rel="stylesheet" type="text/css" href="{{ url('css/bootstrap.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ url('css/font-awesome.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ url('css/style.css') }}">
    @stack('stylesheet')
    <style type="text/css">{!! $mystaticblocks->get('6') !!}</style>
    <style type="text/css">{!! $mystaticblocks->get('7') !!}</style>
    <style type="text/css">{!! $mystaticblocks->get('8') !!}</style>
    <script>
        window.Laravel = <?php
        echo json_encode([
            'csrfToken' => csrf_token(),
            ]);
        ?>
    </script>
</head>
<body>
    <header class="page-navbar">
        <div class="page-navbar-primary">

            @if (Request::path() == '/')
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                {{-- Indicators --}}
                <ol class="carousel-indicators">
                    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="4"></li>
                </ol>

                {{-- Wrapper for slides --}}
                <div class="carousel-inner" role="listbox">
                    {!! $mystaticblocks->get('3') !!}
                </div>

                {{-- Controls --}}
                <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            @endif
        </div>
        <div class="page-navbar-secondary">
            <div class="page-navbar-secondary-fixed">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2 col-xxs-3 brand-logo">
                            <a href="{{ url('') }}"><img src="{{ url('images/icon-small.png') }}"></a>
                        </div>
                        <div class="col-lg-9 col-md-8 col-sm-8 col-xs-6 col-xxs-12 hidden-xxs search-form">
                            <form action="{{ url('search') }}" method="get">
                                <div class="input-group">
                                    <span class="input-group-addon" id="search-keyword"><i class="fa fa-search"></i></span>
                                    <input class="form-control input-search-keyword" type="text" name="keyword" aria-describedby="search-keyword" placeholder="Search" value="@if(isset($keyword)){{ $keyword }}@endif">
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-2 col-md-3 col-sm-3 col-xs-4 col-xxs-9 navbar-secondary">
                            <ul class="nav navbar-nav">
                                <li class="visible-xxs">
                                    <a id="header-navbar-search-toggle" href="#">
                                        <i class="fa fa-search fa-fw"></i>
                                    </a>
                                </li>
                                <li class="dropdown">
                                    <a class="dropdown-toggle" id="dropdownNavbarMain" data-toggle="dropdown" href="#">
                                        <i class="fa fa-bars fa-fw"></i>
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownNavbarMain">
                                        @foreach (DB::table('catalog_categories')->where('parent','0')->get() as $category0)
                                        @if (DB::table('catalog_categories')->where('parent', $category0->id)->count() > 0)
                                        @foreach (DB::table('catalog_categories')->where('parent', $category0->id)->get() as $category1)
                                        @if (DB::table('catalog_categories')->where('parent', $category1->id)->count() > 0)
                                        <li class="dropdown">
                                            <a href="{{ url('category/' . $category1->permalink) }}" class="dropdown-toggle disabled" data-toggle="dropdown" aria-haspopup="true">{{ $category1->title }}</a>
                                            <ul class="dropdown-menu">
                                                @foreach (DB::table('catalog_categories')->where('parent', $category1->id)->get() as $category2)
                                                @if (DB::table('catalog_categories')->where('parent', $category2->id)->count() > 0)
                                                <li>
                                                    <a href="{{ url('category/' . $category2->permalink) }}">{{ $category2->title }}</a>
                                                    <ul class="dropdown-menu">
                                                        @foreach (DB::table('catalog_categories')->where('parent', $category2->id)->get() as $category3)
                                                        @if (DB::table('catalog_categories')->where('parent', $category3->id)->count() > 0)
                                                        <li>
                                                            <a href="{{ url('category/' . $category3->permalink) }}">{{ $category3->title }}</a>
                                                            <ul class="dropdown-menu">
                                                                @foreach (DB::table('catalog_categories')->where('parent', $category3->id)->get() as $category4)
                                                                <li><a href="{{ url('category/' . $category4->permalink) }}">{{ $category4->title }}</a>
                                                                </li>
                                                                @endforeach
                                                            </ul>
                                                        </li>
                                                        @else
                                                        <li><a href="{{ url('category/' . $category3->permalink) }}">{{ $category3->title }}</a></li>
                                                        @endif
                                                        @endforeach
                                                    </ul>
                                                </li>
                                                @else
                                                <li><a href="{{ url('category/' . $category2->permalink) }}">{{ $category2->title }}</a></li>
                                                @endif
                                                @endforeach
                                            </ul>
                                        </li>
                                        @else
                                        <li><a href="{{ url('category/' . $category1->permalink) }}">{{ $category1->title }}</a></li>
                                        @endif
                                        @endforeach
                                        @endif
                                        @endforeach
                                    </ul>
                                </li>
                                <li class="dropdown">
                                    <a class="dropdown-toggle" id="dropdownNavbarUser" data-toggle="dropdown" href="#">
                                        <i class="fa fa-user fa-fw"></i>
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownNavbarUser">
                                        @if ($mycustomer->has_customer() == '1')
                                        <li><a href="{{ url('customer/wishlist') }}">My Wishlist</a></li>
                                        <li><a href="{{ url('customer/account') }}">Account</a></li>
                                        <li><a href="{{ url('customer/logout') }}">Logout</a></li>
                                        @else
                                        <li><a href="{{ url('customer/login') }}">Login</a></li>
                                        <li><a href="{{ url('customer/register') }}">Register</a></li>
                                        @endif
                                    </ul>
                                </li>
                                <li class="dropdown">
                                    <a class="dropdown-toggle" id="dropdownNavbarShoppingCart" data-toggle="dropdown" href="#">
                                        <i class="fa fa-shopping-cart fa-fw"></i>
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownNavbarShoppingCart">
                                        @if (session('shopping-cart') != '')
                                        <li class="shopping-cart">
                                            <span class="total">Total: ${{ number_format(session('shopping-cart-total'), 2) }}</span>
                                        </li>
                                        <li><a href="{{ url('cart') }}">Shopping Cart</a></li>
                                        <li><a href="{{ url('cart/empty-cart') }}">Empty Cart</a></li>
                                        @else
                                        <li class="shopping-cart">You have no items in your shopping cart.</li>
                                        @endif
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    {{-- Check if login user and verify account --}}
    @if ($mycustomer->has_customer() && DB::table('customers')->where('user_id', $mycustomer->get_user_id())->where('verify_code', '!=', '')->count() == '1')
    <div class="container-fluid">
        <div class="alert alert-warning alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-warning pr10"></i> <b>Error:</b> Your account is not yet actived. We had send you email. If you didn't recived yet. Click <a href="{{ url('customer/account/resent-verify-code') }}">here</a> to resent an email.
        </div>
    </div>
    @endif

    @yield('content')

    {{-- Footer --}}
    <footer class="page-footer">
        <div class="container-fluid">
            <div class="copyright-text pull-left">{!! $mystaticblocks->get('4') !!}</div>
            <ul class="nav navbar-nav">
                {!! $mystaticblocks->get('2') !!}
            </ul>
            <div class="payment-method pull-right">
                {!! $mystaticblocks->get('5') !!}
            </div>
        </div>
    </footer>

    {{-- Load JS files --}}
    <script type="text/javascript" src="{{ url('js/jquery.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('js/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('js/masonry-docs.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('js/masonry.pkgd.min.js') }}"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            var window_height = $('html body').height();
            $(window).scroll(function(event) {
                var primary_height = $('.page-navbar .page-navbar-primary').height();
                var height = $(window).scrollTop();
                if (height <= primary_height) {
                    $('.page-navbar .page-navbar-secondary .page-navbar-secondary-fixed').removeClass('fixed');
                } else if (height >= primary_height) {
                    $('.page-navbar .page-navbar-secondary .page-navbar-secondary-fixed').addClass('fixed');
                }
                if (height > 0) {
                    $('.page-navbar .page-navbar-primary .parent-container').css('background-color', '#eee');
                } else {
                    $('.page-navbar .page-navbar-primary .parent-container').css('background-color', 'transparent');
                }
            });
            $('.page-navbar .page-navbar-secondary .search-form .input-search-keyword').focusin(function() {
                $('body').append('<div class="overlay-serach-form" style="width: 100%; height: 100%; position: fixed; top: 0;"></div>');
                $('.search-focus').css('opacity', '0.5');
            });
            $('.page-navbar .page-navbar-secondary .search-form .input-search-keyword').focusout(function() {
                $('body .overlay-serach-form').remove();
                $('.search-focus').css('opacity', '1');
            });
            $('.navbar-secondary .dropdown .shopping-cart').click(function(event) {
                return false;
            });
            var $product_grid = $('.product-grid').masonry({
                itemSelector: '.grid-item',
                percentPosition: true
            });
            $product_grid.imagesLoaded().progress( function() {
                $product_grid.masonry('layout');
            });
            $('.page-navbar .page-navbar-secondary .navbar-secondary .navbar-nav .dropdown a').click(function(event) {
                $('#header-navbar-search-toggle').parent('li').removeClass('open');
                $('.page-navbar .page-navbar-secondary .search-form').addClass('hidden-xxs');
            });
            $('#header-navbar-search-toggle').click(function(event) {
                $(this).parent('li').toggleClass('open');
                $('.page-navbar .page-navbar-secondary .navbar-secondary .navbar-nav .dropdown.open').removeClass('open');
                $('.page-navbar .page-navbar-secondary .search-form').toggleClass('hidden-xxs');
            });

        });
    </script>
    @stack('javascript')
</body>
</html>