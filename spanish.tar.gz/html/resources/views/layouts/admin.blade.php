<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Panel</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="shortcut icon" href="{{ url('images/favicon.png') }}"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='stylesheet' type='text/css' href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800'>
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300">
    <link rel="stylesheet" type="text/css" href="{{ url('assets/skin/default_skin/css/theme.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ url('css/admin.css') }}">
    @stack('stylesheet')
    <script>
        window.Laravel = <?php
        echo json_encode([
            'csrfToken' => csrf_token(),
            ]);
        ?>
    </script>
</head>

<body>

    <!-- Start: Main -->
    <div id="main">

        <!-- Start: Header -->
        <header class="navbar navbar-fixed-top bg-light">
            <div class="navbar-branding bg-light">
                <a class="navbar-brand" href="{{ url('admin') }}"> <b>Agave</b>Rosa </a>
                <span id="toggle_sidemenu_l" class="glyphicons glyphicons-show_lines"></span>
                <ul class="nav navbar-nav pull-right hidden">
                    <li>
                        <a href="#" class="sidebar-menu-toggle">
                            <span class="octicon octicon-ruby fs20 mr10 pull-right "></span>
                        </a>
                    </li>
                </ul>
            </div>
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="{{ url('admin/logout') }}">Logout</a>

                </li>
            </ul>
        </header>
        <!-- End: Header -->

        <!-- Start: Sidebar -->
        <aside id="sidebar_left" class="nano nano-primary sidebar-light light affix has-scrollbar">
            <div class="nano-content" style="right: -17px;">

                <!-- Start: sidebar menu -->
                <ul class="nav sidebar-menu">
                    <li class="sidebar-label pt20">Menu</li>
                    <li @if (isset($active_menu) && $active_menu == 'home') class="active" @endif>
                        <a href="{{ url('admin') }}">
                            <span class="glyphicons glyphicons-home"></span>
                            <span class="sidebar-title">Dashboard</span>
                        </a>
                    </li>
                    <li @if (isset($active_menu) && $active_menu == 'manage-orders') class="active" @endif>
                        <a href="{{ url('admin/manage-orders') }}">
                            <span class="glyphicon glyphicon-list"></span>
                            <span class="sidebar-title">Orders</span>
                        </a>
                    </li>
                    <li{{--  @if (isset($active_menu) && $active_menu == 'catalog') class="active" @endif --}}>
                        {{-- <a class="accordion-toggle @if (isset($active_menu) && $active_menu == 'catalog') menu-open @endif" href="#"> --}}
                        <a class="{{-- accordion-toggle --}} menu-open" href="#">
                            <span class="glyphicons glyphicons-shopping_cart"></span>
                            <span class="sidebar-title">Catalog</span>
                            {{-- <span class="caret"></span> --}}
                        </a>
                        <ul class="nav sub-nav">
                            <li @if (isset($active_submenu) && $active_submenu == 'manage-products') class="active" @endif>
                                <a href="{{ url('admin/catalog/manage-products') }}">Manage Products</a>
                            </li>
                            <li @if (isset($active_submenu) && $active_submenu == 'manage-categories') class="active" @endif>
                                <a href="{{ url('admin/catalog/manage-categories') }}">Manage Categories</a>
                            </li>
                            <li @if (isset($active_submenu) && $active_submenu == 'manage-attributes') class="active" @endif>
                                <a href="{{ url('admin/catalog/manage-attributes') }}">Manage Attributes</a>
                            </li>
                        </ul>
                    </li>
                    <li @if (isset($active_menu) && $active_menu == 'manage-coupons') class="active" @endif>
                        <a href="{{ url('admin/manage-coupons') }}">
                            <span class="glyphicon glyphicon-retweet"></span>
                            <span class="sidebar-title">Manage Coupons</span>
                        </a>
                    </li>
                    <li @if (isset($active_menu) && $active_menu == 'manage-users') class="active" @endif>
                        <a href="{{ url('admin/manage-users') }}">
                            <span class="glyphicon glyphicon-user"></span>
                            <span class="sidebar-title">Manage Users</span>
                        </a>
                    </li>
                    <li class="sidebar-label pt20">CMS</li>
                    <li @if (isset($active_menu) && $active_menu == 'manage-pages') class="active" @endif>
                        <a href="{{ url('admin/manage-pages') }}">
                            <span class="glyphicons glyphicons-book"></span>
                            <span class="sidebar-title">Manage Pages</span>
                        </a>
                    </li>
                    <li @if (isset($active_menu) && $active_menu == 'manage-staticblocks') class="active" @endif>
                        <a href="{{ url('admin/manage-staticblocks') }}">
                            <span class="glyphicon glyphicon-th-large"></span>
                            <span class="sidebar-title">Manage Staticblocks</span>
                        </a>
                    </li>
                    <!-- End: sidebar menu -->

                </ul>
            </div>
        </aside>

        <!-- Start: Content-Wrapper -->
        <section id="content_wrapper">

        @yield('content')

        </section>

    </div>
    <!-- End: Main -->

    <!-- BEGIN: PAGE SCRIPTS -->

    <!-- jQuery -->
    <script type="text/javascript" src="{{ url('vendor/jquery/jquery-1.11.1.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('vendor/jquery/jquery_ui/jquery-ui.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/bootstrap/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/utility/utility.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/main.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/demo.js') }}"></script>
    <script type="text/javascript" src="{{ url('js/admin.js') }}"></script>
    <script type="text/javascript">
        jQuery(document).ready(function() {
            "use strict";
            // Init Theme Core
            Core.init();
            // Init Theme Core
            Demo.init();
        });
    </script>
    @stack('javascript')
    <!-- END: PAGE SCRIPTS -->

</body>

</html>
