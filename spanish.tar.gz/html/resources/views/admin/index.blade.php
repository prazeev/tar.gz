@extends('layouts.admin')

@push('stylesheet')
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin') }}">Dashboard</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin') }}">Home</a>
            </li>
            <li class="crumb-trail">Dashboard</li>
        </ol>
    </div>
    <div class="topbar-right">
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">
    <div class="row">
        <div class="col-sm-4 col-md-3">
            <div class="panel panel-tile text-center">
                <div class="panel-body bg-default light">
                    <i class="glyphicon glyphicon-list text-muted fs70 mt10"></i>
                    <h1 class="fs35 mbn">0</h1>
                    <a href="{{ url('admin/manage-orders' )}}"><h6 class="text-system">Orders</h6></a>
                </div>
                <div class="panel-footer bg-default br-n p12">
                    <span class="fs11"><b>Total Product Orders</b>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-4 col-md-3">
            <div class="panel panel-tile text-center">
                <div class="panel-body bg-default light">
                    <i class="glyphicon glyphicon-shopping-cart text-muted fs70 mt10"></i>
                    <h1 class="fs35 mbn">{{ DB::table('catalog_products')->count() }}</h1>
                    <a href="{{ url('admin/manage-products' )}}"><h6 class="text-system">Products</h6></a>
                </div>
                <div class="panel-footer bg-default br-n p12">
                    <span class="fs11"><b>Total Posted Poducts</b>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-4 col-md-3">
            <div class="panel panel-tile text-center">
                <div class="panel-body bg-default light">
                    <i class="glyphicon glyphicon-user text-muted fs70 mt10"></i>
                    <h1 class="fs35 mbn">{{ DB::table('users')->count() }}</h1>
                    <a href="{{ url('admin/manage-users' )}}"><h6 class="text-system">Users</h6></a>
                </div>
                <div class="panel-footer bg-default br-n p12">
                    <span class="fs11"><b>Total Registered Users</b>
                    </span>
                </div>
            </div>
        </div>
        <div class="col-sm-4 col-md-3">
            <div class="panel panel-tile text-center">
                <div class="panel-body bg-default light">
                    <i class="glyphicon glyphicon-book text-muted fs70 mt10"></i>
                    <h1 class="fs35 mbn">{{ DB::table('pages')->count() }}</h1>
                    <a href="{{ url('admin/manage-pages' )}}"><h6 class="text-system">Pages</h6></a>
                </div>
                <div class="panel-footer bg-default br-n p12">
                    <span class="fs11"><b>Total Published Pages</b>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="panel">
        <div class="panel-heading">
            <span class="panel-title"><i class="fa fa-shopping-cart"></i> This month (<?php echo date('M'); ?>)</span>
        </div>
        <div class="panel-body pn">
            <div id="this-month-chart-container" style="min-width: 310px; height: 400px; max-width: 100%; margin: 0 auto"></div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="panel">
                <div class="panel-heading">
                    <span class="panel-title"><i class="fa fa-shopping-cart"></i> Last month (<?php echo date('M', strtotime('first day of -1 month')); ?>)</span>
                </div>
                <div class="panel-body pn">
                    <div id="last-month-chart-container" style="min-width: 310px; height: 400px; max-width: 100%; margin: 0 auto"></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="panel">
                <div class="panel-heading">
                    <span class="panel-title"><i class="fa fa-shopping-cart"></i> Month before last month (<?php echo date('M', strtotime('first day of -2 month')); ?>)</span>
                </div>
                <div class="panel-body pn">
                    <div id="month-before-last-month-chart-container" style="min-width: 310px; height: 400px; max-width: 100%; margin: 0 auto"></div>
                </div>
            </div>
        </div>
    </div>

    

    <div class="panel">
        <div class="panel-heading">
            <span class="panel-title"><i class="fa fa-shopping-cart"></i> Orders</span>
        </div>
        <div class="panel-body pn">
            <div id="order-chart-container" style="min-width: 310px; height: 400px; max-width: 100%; margin: 0 auto"></div>
        </div>
    </div>

</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script src="{{ url('js/highcharts.js') }}"></script>
<script type="text/javascript">
    $(function () {
        Highcharts.chart('order-chart-container', {
            title: {
                text: 'ORDERS CHART OVERALL',
            x: -20 //center
        },
        xAxis: {
            categories: [
            "<?php echo date('M', strtotime('first day of -11 month')); ?>",
            "<?php echo date('M', strtotime('first day of -10 month')); ?>",
            "<?php echo date('M', strtotime('first day of -9 month')); ?>",
            "<?php echo date('M', strtotime('first day of -8 month')); ?>",
            "<?php echo date('M', strtotime('first day of -7 month')); ?>",
            "<?php echo date('M', strtotime('first day of -6 month')); ?>",
            "<?php echo date('M', strtotime('first day of -5 month')); ?>",
            "<?php echo date('M', strtotime('first day of -4 month')); ?>",
            "<?php echo date('M', strtotime('first day of -3 month')); ?>",
            "<?php echo date('M', strtotime('first day of -2 month')); ?>",
            "<?php echo date('M', strtotime('first day of -1 month')); ?>",
            "<?php echo date('M'); ?>"
            ]
        },
        yAxis: {
            title: {
                text: 'Number of orders'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ''
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: [{
            name: 'Pending',
            data: [
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -11 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -10 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -10 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -9 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -9 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -8 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -8 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -7 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -7 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -6 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -6 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -5 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -5 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -4 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -4 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -3 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -3 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -2 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -2 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -1 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -1 month')))->where('created_at', '<', date('Y-m'))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m'))->count(); ?>
            ]
        }, {
            name: 'Processing',
            data: [
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -11 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -10 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -10 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -9 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -9 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -8 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -8 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -7 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -7 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -6 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -6 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -5 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -5 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -4 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -4 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -3 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -3 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -2 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -2 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -1 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -1 month')))->where('created_at', '<', date('Y-m'))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m'))->count(); ?>
            ]
        }, {
            name: 'Delivering',
            data: [
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -11 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -10 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -10 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -9 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -9 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -8 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -8 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -7 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -7 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -6 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -6 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -5 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -5 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -4 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -4 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -3 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -3 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -2 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -2 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -1 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -1 month')))->where('created_at', '<', date('Y-m'))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m'))->count(); ?>
            ]
        }, {
            name: 'Completed',
            data: [
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -11 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -10 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -10 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -9 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -9 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -8 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -8 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -7 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -7 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -6 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -6 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -5 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -5 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -4 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -4 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -3 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -3 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -2 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -2 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -1 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -1 month')))->where('created_at', '<', date('Y-m'))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m'))->count(); ?>
            ]
        }, {
            name: 'Canceled',
            data: [
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -11 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -10 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -10 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -9 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -9 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -8 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -8 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -7 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -7 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -6 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -6 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -5 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -5 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -4 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -4 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -3 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -3 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -2 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -2 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -1 month')))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -1 month')))->where('created_at', '<', date('Y-m'))->count(); ?>,
            <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m'))->count(); ?>
            ]
        }]
    });


        Highcharts.chart('this-month-chart-container', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Total Visual representation of this month\'s orders'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            series: [{
                name: 'Orders',
                colorByPoint: true,
                data: [{
                    name: 'Pending',
                    y: <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m'))->count(); ?>
                }, {
                    name: 'Processing',
                    y: <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m'))->count(); ?>,
                    sliced: true,
                    selected: true
                }, {
                    name: 'Delivering',
                    y: <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m'))->count(); ?>
                }, {
                    name: 'Completed',
                    y: <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m'))->count(); ?>
                }, {
                    name: 'Canceled',
                    y: <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m'))->count(); ?>
                }]
            }]
        });

        Highcharts.chart('last-month-chart-container', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Total Visual representation of last month\'s orders'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            series: [{
                name: 'Orders',
                colorByPoint: true,
                data: [{
                    name: 'Pending',
                    y: <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -1 month')))->where('created_at', '<', date('Y-m'))->count(); ?>
                }, {
                    name: 'Processing',
                    y: <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -1 month')))->where('created_at', '<', date('Y-m'))->count(); ?>,
                    sliced: true,
                    selected: true
                }, {
                    name: 'Delivering',
                    y: <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -1 month')))->where('created_at', '<', date('Y-m'))->count(); ?>
                }, {
                    name: 'Completed',
                    y: <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -1 month')))->where('created_at', '<', date('Y-m'))->count(); ?>
                }, {
                    name: 'Canceled',
                    y: <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -1 month')))->where('created_at', '<', date('Y-m'))->count(); ?>
                }]
            }]
        });

        Highcharts.chart('month-before-last-month-chart-container', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'Total Visual representation of month before month\'s orders'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            series: [{
                name: 'Orders',
                colorByPoint: true,
                data: [{
                    name: 'Pending',
                    y: <?php echo DB::table('checkouts')->where('status', '1')->where('created_at', '>=', date('Y-m', strtotime('first day of -2 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -1 month')))->count(); ?>
                }, {
                    name: 'Processing',
                    y: <?php echo DB::table('checkouts')->where('status', '70')->where('created_at', '>=', date('Y-m', strtotime('first day of -2 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -1 month')))->count(); ?>,
                    sliced: true,
                    selected: true
                }, {
                    name: 'Delivering',
                    y: <?php echo DB::table('checkouts')->where('status', '80')->where('created_at', '>=', date('Y-m', strtotime('first day of -2 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -1 month')))->count(); ?>
                }, {
                    name: 'Completed',
                    y: <?php echo DB::table('checkouts')->where('status', '90')->where('created_at', '>=', date('Y-m', strtotime('first day of -2 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -1 month')))->count(); ?>
                }, {
                    name: 'Canceled',
                    y: <?php echo DB::table('checkouts')->where('status', '11')->where('created_at', '>=', date('Y-m', strtotime('first day of -2 month')))->where('created_at', '<', date('Y-m', strtotime('first day of -1 month')))->count(); ?>
                }]
            }]
        });

});
</script>

@endpush
