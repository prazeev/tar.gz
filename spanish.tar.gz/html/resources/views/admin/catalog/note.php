
{{-- <td>
    <select class="form-control" name="image-color[]">
        @foreach (DB::table('catalog_attribute_options')->where('attribute_id', DB::table('catalog_attributes')->where('title', 'Colors')->first()->id)->get() as $color)
            <option value="{{ $color->id }}">{{ $color->admin_value }}</option>
        @endforeach
    </select>
</td> --}}


{{-- <th>Color</th> --}}
