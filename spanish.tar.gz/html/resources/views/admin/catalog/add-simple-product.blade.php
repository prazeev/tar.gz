@extends('layouts.admin')

@push('stylesheet')
<link rel="stylesheet" type="text/css" href="{{ url('assets/admin-tools/admin-forms/css/admin-forms.css') }}">
<style>
    .form-control[type="radio"] {
        margin: 0;
        height: 20px;
    }
    img[src=""] {
        display: block;
        width: 100%;
        height: 39px;
        font-size: 13px;
        line-height: 1.5;
        color: #555555;
        background-color: #ffffff;
        background-image: none;
        border-radius: 0px;
        -webkit-transition: border-color ease-in-out .15s;
        -o-transition: border-color ease-in-out .15s;
        transition: border-color ease-in-out .15s;
    }
</style>
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/catalog/manage-products/add-simple-product') }}">Add Simple Product</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/catalog/manage-products') }}">Manage Products</a>
            </li>
            <li class="crumb-trail">Add Simple Product</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/catalog/manage-products') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">
    <form class="form-horizontal" role="form" action="{{ url('admin/catalog/manage-products/add-simple-product') }}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="panel">
            <div class="panel-body text-right">
                <h4 class="pull-left">Create new simple product</h4>
                <a class="btn btn-warning btn-sm" href="{{ url('admin/catalog/manage-products/add-simple-product') }}">Reset</a>
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Product">
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Product & Continue Edit">
            </div>
        </div>

        @if (Session::has('error-alert'))
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
            </div>
        @elseif (Session::has('success-alert'))
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
            </div>
        @endif

        <div class="panel">
            <div class="panel-heading">
                <ul class="nav panel-tabs-border panel-tabs">
                    <li class="active">
                        <a href="#general-information" data-toggle="tab">General Information</a>
                    </li>
                    <li>
                        <a href="#attribute-information" data-toggle="tab">Attribute Information</a>
                    </li>
                    <li>
                        <a href="#meta-information" data-toggle="tab">Meta Information</a>
                    </li>
                    <li>
                        <a href="#images" data-toggle="tab">Images</a>
                    </li>
                    <li>
                        <a href="#categories" data-toggle="tab">Categories</a>
                    </li>
                </ul>
            </div>
            <div class="panel-body">
                <div class="tab-content pn br-n">
                    <div id="general-information" class="tab-pane active">
                        <div class="form-group">
                            <label for="inputTitle" class="col-lg-3 control-label">Product Title</label>
                            <div class="col-lg-8">
                                <input type="text" name="title" id="inputTitle" class="form-control" placeholder="Product Title" required="required">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputStatus" class="col-lg-3 control-label">Status</label>
                            <div class="col-lg-8">
                                <select id="inputStatus" name="status" required="required">
                                    <option value="1" selected="selected">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group textfield-default">
                            <label for="inputPermalink" class="col-lg-3 control-label">Permalink</label>
                            <div class="col-lg-8">
                                <input type="text" name="permalink" id="inputPermalink" class="form-control" placeholder="Permalink" required="required">
                                <span id="inputPermalinkAlert"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputTagline" class="col-lg-3 control-label">Product Tagline</label>
                            <div class="col-lg-8">
                                <textarea id="inputTagline" class="form-control" name="tagline" placeholder="Tagline"></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputDescription" class="col-lg-3 control-label">Product Description</label>
                            <div class="col-lg-8">
                                <textarea id="inputDescription" class="form-control" name="description" placeholder="Description" rows="5"></textarea>
                            </div>
                        </div>
                    </div>
                    <div id="attribute-information" class="tab-pane">
                        @foreach (DB::table('catalog_attributes')->orderBy('id')->get() as $attribute)
                            <div class="form-group">
                                <label for="inputAttribute{{ $attribute->title }}" class="col-lg-3 control-label">Attribute {{ $attribute->title }}</label>
                                <div class="col-lg-8">
                                    @if ($attribute->type == 'textfield')
                                        @if ($attribute->title == 'Price')
                                            <span class="append-icon left"><i class="fa fa-usd"></i></span>
                                            <input type="text" name="attribute-{{ $attribute->id }}" class="form-control" id="inputAttribute{{ $attribute->title }}" placeholder="{{ $attribute->title }}" value="{{ $attribute->textfield }}">
                                        @elseif ($attribute->title == 'Discount' || $attribute->title == 'Tax')
                                            <span class="append-icon right">%</span>
                                            <input type="text" name="attribute-{{ $attribute->id }}" class="form-control" id="inputAttribute{{ $attribute->title }}" placeholder="{{ $attribute->title }}" value="{{ $attribute->textfield }}">
                                        @else
                                            <input type="text" name="attribute-{{ $attribute->id }}" id="inputAttribute{{ $attribute->title }}" class="form-control" placeholder="{{ $attribute->title }}" value="{{ $attribute->textfield }}">
                                        @endif
                                    @elseif ($attribute->type == 'textarea')
                                        <textarea id="inputAttribute{{ $attribute->title }}" class="form-control" name="attribute-{{ $attribute->id }}" placeholder="{{ $attribute->title }}">{{ $attribute->textarea }}</textarea>
                                    @elseif ($attribute->type == 'dropdown')
                                        <select id="inputAttribute{{ $attribute->title }}" class="form-control" name="attribute-{{ $attribute->id }}">
                                            @foreach (DB::table('catalog_attribute_options')->where('attribute_id', $attribute->id)->orderBy('order')->get() as $option)
                                                <option value="{{ $option->id }}">{{ $option->admin_value }}</option>
                                            @endforeach
                                        </select>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div id="meta-information" class="tab-pane">
                        <div class="form-group">
                            <label for="inputMetaTitle" class="col-lg-3 control-label">Meta Title</label>
                            <div class="col-lg-8">
                                <input type="text" name="meta-title" id="inputMetaTitle" class="form-control" placeholder="Meta Title">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputMetaKeywords" class="col-lg-3 control-label">Meta Keywords</label>
                            <div class="col-lg-8">
                                <textarea id="inputMetaKeywords" class="form-control" name="meta-keywords" placeholder="Meta Keywords"></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputMetaDescription" class="col-lg-3 control-label">Meta Description</label>
                            <div class="col-lg-8">
                                <textarea id="inputMetaDescription" class="form-control" name="meta-description" placeholder="Meta Description"></textarea>
                            </div>
                        </div>
                    </div>
                    <div id="images" class="tab-pane">
                        <a id="add-image" class="btn btn-primary"><i class="fa fa-plus"></i> Add Image</a>
                        <span class="pull-right mt10">[ Every image must be at least 512x512 px ]</span>
                        <table class="table table-bordered table-images mt15">
                            <thead>
                                <tr class="system">
                                    <th>Image Title</th>
                                    <th class="text-center">Default</th>
                                    <th style="width: 100px;">Order</th>
                                    <th class="text-center">Image</th>
                                    <th>Select Image</th>
                                    <th class="text-center" style="width: 100px;">Option</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><input class="form-control" type="text" name="image-title[]"></td>
                                    <td><input class="input-image-default" type="hidden" name="image-default[]" value="1"><input class="form-control image-default-radio" type="radio" name="image-default-radio" checked="checked"></td>
                                    <td><input class="form-control" type="text" name="image-order[]"></td>
                                    <td class="text-center"><img src="" alt="No Img"></td>
                                    <td><input class="form-control" type="file" name="image[]"></td>
                                    <td class="text-center"><a class="btn btn-danger btn-delete-image" href="#"><i class="fa fa-close"></i> Delete</a></td>
                                </tr>
                            </tbody>
                        </table>

                        <ul class="mt15">
                            <li>Icon: 64x64 px</li>
                            <li>Small image: 64 px width</li>
                            <li>Medium image: 256 px width</li>
                            <li>Large image: 512 px width</li>
                            <li>And one orgianl image</li>
                        </ul>
                    </div>
                    <div id="categories" class="tab-pane">
                        <h4 class="mt5 mb20">Categories</h4>
                        <ul class="list-unstyled">
                        @foreach (DB::table('catalog_categories')->where('parent','0')->get() as $category0)
                            <li>
                                <label><input type="checkbox" name="categories[]" value="{{ $category0->id }}" checked="checked"> <i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category0->title }}</label>
                            @if (DB::table('catalog_categories')->where('parent', $category0->id)->count() > 0)
                                <ul class="list-unstyled  ml20">
                                @foreach (DB::table('catalog_categories')->where('parent', $category0->id)->get() as $category1)
                                    <li>
                                    <label><input type="checkbox" name="categories[]" value="{{ $category1->id }}"> <i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category1->title }}</label>
                                    @if (DB::table('catalog_categories')->where('parent', $category1->id)->count() > 0)
                                        <ul class="list-unstyled  ml20">
                                        @foreach (DB::table('catalog_categories')->where('parent', $category1->id)->get() as $category2)
                                            <li>
                                                <label><input type="checkbox" name="categories[]" value="{{ $category2->id }}"> <i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category2->title }}</label>
                                            @if (DB::table('catalog_categories')->where('parent', $category2->id)->count() > 0)
                                                <ul class="list-unstyled  ml20">
                                                @foreach (DB::table('catalog_categories')->where('parent', $category2->id)->get() as $category3)
                                                    <li>
                                                        <label><input type="checkbox" name="categories[]" value="{{ $category3->id }}"> <i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category3->title }}</label>
                                                    @if (DB::table('catalog_categories')->where('parent', $category3->id)->count() > 0)
                                                        <ul class="list-unstyled  ml20">
                                                        @foreach (DB::table('catalog_categories')->where('parent', $category3->id)->get() as $category4)
                                                            <li>
                                                                <label><input type="checkbox" name="categories[]" value="{{ $category4->id }}"> <i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category4->title }}</label>
                                                            </li>
                                                        @endforeach
                                                        </ul>
                                                    @endif
                                                    </li>
                                                @endforeach
                                                </ul>
                                            @endif
                                            </li>
                                        @endforeach
                                        </ul>
                                    @endif
                                    </li>
                                @endforeach
                                </ul>
                            @endif
                            </li>
                        @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div
    </form>
</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript">
    $(document).ready(function() {
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

        $('#inputStatus').multiselect();
        $('#inputAttributeColor').multiselect();
        $('#inputAttributeSize').multiselect();

        $('#inputPermalink').keyup(function(event) {
            var permalink = $(this).val();
            $.post('{{ url('admin/catalog/manage-products/api') }}', {_token: CSRF_TOKEN, action: 'check-permalink', permalink: permalink}, function(result) {
                if(result == '1') {
                    $('#inputPermalinkAlert').html('');
                } else {
                    $('#inputPermalinkAlert').html('<div class="alert alert-danger alert-sm mt10"><b>Error:</b> Permalink is not available!</div>');
                }
            });
        });

        $(document).on('click', '.btn-delete-image', function() {
            $(this).parent('td').parent('tr').remove();
            return false;
        });

        $(document).on('click', '.image-default-radio', function() {
            $('.input-image-default').val('0');
            $(this).parent('td').children('.input-image-default').val('1');
        });

        $(document).on('click', '#add-image', function() {
            $('.table-images').children('tbody').prepend('<tr><td><input class="form-control" type="text" name="image-title[]"></td><td><input class="input-image-default" type="hidden" name="image-default[]" value="0"><input class="form-control image-default-radio" type="radio" name="image-default-radio"></td><td><input class="form-control" type="text" name="image-order[]"></td><td class="text-center"><img src="" alt="No Img"></td><td><input class="form-control" type="file" name="image[]"></td><td class="text-center"><a class="btn btn-danger btn-delete-image" href="#"><i class="fa fa-close"></i> Delete</a></td></tr>');
            return false;
        });

    });
</script>

@endpush
