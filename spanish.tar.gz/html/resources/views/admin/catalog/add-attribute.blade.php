@extends('layouts.admin')

@push('stylesheet')
<style type="text/css">
    .img-swatches {
        width: 46px;
        height: 46px;
    }
</style>
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/catalog/manage-attributes/add-attribute') }}">Add Attribute</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/catalog/manage-attributes') }}">Manage Attributes</a>
            </li>
            <li class="crumb-trail">Add Attribute</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/catalog/manage-attributes') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">

    <form class="form-horizontal" role="form" action="{{ url('admin/catalog/manage-attributes/add-attribute') }}" method="post">
        {{ csrf_field() }}
        <div class="panel">
            <div class="panel-body text-right">
                <h4 class="pull-left">Create new attribute</h4>
                <a class="btn btn-warning btn-sm" href="{{ url('admin/catalog/manage-attributes/add-attribute') }}">Reset</a>
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Attribute">
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Attribute & Continue Edit">
            </div>
        </div>

        @if (Session::has('error-alert'))
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
            </div>
        @elseif (Session::has('success-alert'))
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
            </div>
        @endif

        <div class="panel">
            <div class="panel-heading">
                <ul class="nav panel-tabs-border panel-tabs">
                    <li class="active">
                        <a href="#peroperties" data-toggle="tab">Properties</a>
                    </li>
                    <li>
                        <a href="#frontend" data-toggle="tab">Frontend</a>
                    </li>
                    <li>
                        <a href="#options" data-toggle="tab">Options</a>
                    </li>
                </ul>
            </div>
            <div class="panel-body">
                <div class="tab-content pn br-n">
                    <div id="peroperties" class="tab-pane active">
                        <div class="form-group">
                            <label for="inputTitle" class="col-lg-3 control-label">Attribute Title</label>
                            <div class="col-lg-8">
                                <input type="text" name="title" id="inputTitle" class="form-control" placeholder="Attribute Title" required="required">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputType" class="col-lg-3 control-label">Attribute Type</label>
                            <div class="col-lg-8">
                                <select id="inputType" name="type" required="required">
                                    <option value="textfield">Text Field</option>
                                    <option value="textarea">Text Area</option>
                                    <option value="dropdown">Dropdown</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group textfield-default">
                            <label for="inputDefault" class="col-lg-3 control-label">Default Value</label>
                            <div class="col-lg-8">
                                <input type="text" name="textfield-default" id="inputDefault" class="form-control" placeholder="Default Value">
                            </div>
                        </div>
                        <div class="form-group textarea-default" style="display: none;">
                            <label for="inputDefault" class="col-lg-3 control-label">Default Value</label>
                            <div class="col-lg-8">
                                <textarea id="inputDefault" class="form-control" name="textarea-default" placeholder="Default Value"></textarea>
                            </div>
                        </div>
                    </div>
                    <div id="frontend" class="tab-pane">
                        <div class="form-group">
                            <label class="col-lg-3 control-label">Use in Quick Search</label>
                            <div class="col-lg-8">
                                <select id="inputQuickSearch" name="quick-search" required="required">
                                    <option value="1">Yes</option>
                                    <option value="0" selected="selected">No</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-3 control-label">Use in Advanced Search</label>
                            <div class="col-lg-8">
                                <select id="inputAdvanceSearch" name="advance-search" required="required">
                                    <option value="1">Yes</option>
                                    <option value="0" selected="selected">No</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div id="options" class="tab-pane">
                        <div class="well text-center no-option-needed">No option needed</div>
                        <div class="well text-center swatches" style="display: none;"><b>Save to add options</b></div>
                    </div>
                </div>
            </div>
        </div>
    </form>

</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript">
    $(document).ready(function() {

        $('.fileupload-preview').on('click', function() {
            $('.btn-file > input').click();
        });

        $('#inputType').multiselect();
        $('#inputQuickSearch').multiselect();
        $('#inputAdvanceSearch').multiselect();
        $('#inputSwatches').multiselect();

        $(document).on('change', '#inputType', function(event) {
            var val = $(this).val();
            if(val == 'textfield') {
                $('.swatches').hide('slow');
                $('.textarea-default').hide('slow');
                $('.no-option-needed').show('slow');
                $('.textfield-default').show('slow');
            } else if(val == 'textarea') {
                $('.swatches').hide('slow');
                $('.textfield-default').hide('slow');
                $('.no-option-needed').show('slow');
                $('.textarea-default').show('slow');
            } else if(val == 'dropdown') {
                $('.textfield-default').hide('slow');
                $('.textarea-default').hide('slow');
                $('.no-option-needed').hide('slow');
                $('.swatches').show('slow');
                $('.table-options').show('slow');
            }

        });

        $(document).on('change', '#inputSwatches', function() {
            var val = $(this).val();
            if(val == '1') {
                $('.td-swatches').fadeIn('slow');
            } else if (val == '0') {
                $('.td-swatches').fadeOut('slow');
            }
        });

    });
</script>

@endpush
