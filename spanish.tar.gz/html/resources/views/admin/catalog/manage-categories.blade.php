@extends('layouts.admin')

@push('stylesheet')
<link rel="stylesheet" type="text/css" href="{{ url('vendor/plugins/datatables/media/css/dataTables.bootstrap.css') }}">
<style type="text/css">
    a.nostyle {
        color: #666;
        text-decoration: none;
    }
    a.nostyle:hover {
        color: #333;
    }
    a.nostyle.active,
    a.nostyle.active:hover {
        font-weight: bold;
    }
</style>
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/catalog/manage-categories') }}">Manage Categories</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-trail">Manage Categories</li>
        </ol>
    </div>
    <div class="topbar-right">
        @if ($view_type != 'create-new-subcategory' && $category_level < 4)
        <a class="btn btn-default btn-sm" href="{{ url('admin/catalog/manage-categories/' . $category_id . '/add-new-subcategory') }}"><i class="fa fa-plus"></i> Add Subcategory</a>
        @elseif ($view_type == 'create-new-subcategory' && $category_level < 4)
        <a class="btn btn-default btn-sm" href="{{ url('admin/catalog/manage-categories/' . $category_id) }}"><i class="fa fa-arrow-left"></i> Back</a>
        @endif
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn table-layout">


    <!-- begin: .tray-left -->
    <aside class="tray tray-left tray320 va-t pn" data-tray-height="match">

        <div class="p20">
            <h4 class="mt5 mb20">Categories</h4>
            <ul class="list-unstyled">
            @foreach (DB::table('catalog_categories')->where('parent','0')->get() as $category0)
                <li>
                    <a class="nostyle @if ($category_id == $category0->id) active @endif" href="{{ url('admin/catalog/manage-categories/'.$category0->id) }}"><i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category0->title }} </a>
                @if (DB::table('catalog_categories')->where('parent', $category0->id)->count() > 0)
                    <ul class="list-unstyled  ml20">
                    @foreach (DB::table('catalog_categories')->where('parent', $category0->id)->get() as $category1)
                        <li>
                        <a class="nostyle @if ($category_id == $category1->id) active @endif" href="{{ url('admin/catalog/manage-categories/'.$category1->id) }}"><i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category1->title }} </a>
                        @if (DB::table('catalog_categories')->where('parent', $category1->id)->count() > 0)
                            <ul class="list-unstyled  ml20">
                            @foreach (DB::table('catalog_categories')->where('parent', $category1->id)->get() as $category2)
                                <li>
                                    <a class="nostyle @if ($category_id == $category2->id) active @endif" href="{{ url('admin/catalog/manage-categories/'.$category2->id) }}"><i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category2->title }} </a>
                                @if (DB::table('catalog_categories')->where('parent', $category2->id)->count() > 0)
                                    <ul class="list-unstyled  ml20">
                                    @foreach (DB::table('catalog_categories')->where('parent', $category2->id)->get() as $category3)
                                        <li>
                                            <a class="nostyle @if ($category_id == $category3->id) active @endif" href="{{ url('admin/catalog/manage-categories/'.$category3->id) }}"><i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category3->title }} </a>
                                        @if (DB::table('catalog_categories')->where('parent', $category3->id)->count() > 0)
                                            <ul class="list-unstyled  ml20">
                                            @foreach (DB::table('catalog_categories')->where('parent', $category3->id)->get() as $category4)
                                                <li>
                                                    <a class="nostyle @if ($category_id == $category4->id) active @endif" href="{{ url('admin/catalog/manage-categories/'.$category4->id) }}"><i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category4->title }} </a>
                                                </li>
                                            @endforeach
                                            </ul>
                                        @endif
                                        </li>
                                    @endforeach
                                    </ul>
                                @endif
                                </li>
                            @endforeach
                            </ul>
                        @endif
                        </li>
                    @endforeach
                    </ul>
                @endif
                </li>
            @endforeach
            </ul>

        </div>
    </aside>
    <!-- end: .tray-left -->



    <!-- begin: .tray-center -->
    <div class="tray tray-center va-t posr">
        <div class="row">
            <div class="col-sm-12 mw800 admin-grid">
                <form class="form-horizontal" role="form" action="{{ url('admin/catalog/manage-categories/' . $category_details->id . '/process') }}" method="post">
                    {{ csrf_field() }}
                    <input type="hidden" name="submit-type" value="{{ $view_type }}">
                    <div class="panel">
                        <div class="panel-body text-right">
                            @if ($view_type == 'create-new-subcategory')
                            <h4 class="pull-left">Create new category under <b>"{{ $category_details->title }}"</b></h4>
                            <a class="btn btn-warning btn-sm" href="{{ url('admin/catalog/manage-categories/' . $category_id . '/add-new-subcategory') }}">Reset</a>
                            <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Category">
                            <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Category & Continue Edit">
                            @elseif ($view_type == 'edit-category')
                            <h4 class="pull-left">Edit: {{ $category_details->title }}</h4>
                            <a class="btn btn-warning btn-sm" href="{{ url('admin/catalog/manage-categories/' . $category_id) }}">Reset</a>

                            @if ($category_id != '1')
                            <a class="btn btn-danger btn-delete btn-sm" href="{{ url('admin/catalog/manage-categories/' . $category_id . '/delete') }}">Delete Category</a>
                            @endif
                            <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Category">
                            @endif

                        </div>
                    </div>

                    @if (Session::has('error-alert'))
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
                        </div>
                    @elseif (Session::has('success-alert'))
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
                        </div>
                    @endif

                    <div class="panel">
                        <div class="panel-heading">
                            <ul class="nav panel-tabs-border panel-tabs">
                                <li class="active">
                                    <a href="#general-information" data-toggle="tab">General Information</a>
                                </li>
                                <li>
                                    <a href="#meta-information" data-toggle="tab">Meta Information</a>
                                </li>
                                <li>
                                    <a href="#category-products" data-toggle="tab">Category Products</a>
                                </li>
                            </ul>
                        </div>
                        <div class="panel-body">
                            <div class="tab-content pn br-n">
                                <div id="general-information" class="tab-pane active">
                                    <div class="form-group">
                                        <label for="inputTitle" class="col-lg-3 control-label">Title</label>
                                        <div class="col-lg-8">
                                            <input type="text" name="title" id="inputTitle" class="form-control" placeholder="Title" required="required" @if ($view_type == 'edit-category') value="{{ $category_details->title }}" @endif>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputStatus" class="col-lg-3 control-label">Status</label>
                                        <div class="col-lg-8">
                                            <select id="inputStatus" name="status" required="required">
                                                <option value="1" @if ($view_type == 'edit-category' && $category_details->status == '1') selected="selected" @elseif ($view_type == 'create-new-subcategory') selected="selected" @endif>Active</option>
                                                <option value="0" @if ($view_type == 'edit-category' && $category_details->status == '0') selected="selected" @endif>Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="inputPermalink" class="col-lg-3 control-label">Permalink</label>
                                        <div class="col-lg-8">
                                            <input type="text" name="permalink" id="inputPermalink" class="form-control" placeholder="Permalink" required="required" @if ($view_type == 'edit-category') value="{{ $category_details->permalink }}" @endif>
                                            <span id="inputPermalinkAlert"></span>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-3 control-label" for="inputDescription">Description</label>
                                        <div class="col-lg-8">
                                            <textarea name="description" class="form-control" id="inputDescription" rows="3" placeholder="Description">@if ($view_type == 'edit-category'){{ $category_details->description }}@endif</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div id="meta-information" class="tab-pane">
                                    <div class="form-group">
                                        <label for="inputMetaTitle" class="col-lg-3 control-label">Meta Title</label>
                                        <div class="col-lg-8">
                                            <input type="text" name="meta-title" id="inputMetaTitle" class="form-control" placeholder="Meta Title" @if ($view_type == 'edit-category') value="{{ $category_details->meta_title }}" @endif>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-3 control-label" for="inputMetaKeywords">Meta Keywords</label>
                                        <div class="col-lg-8">
                                            <textarea name="meta-keywords" class="form-control" id="inputMetaKeywords" rows="3" placeholder="Meta Keywords">@if ($view_type == 'edit-category'){{ $category_details->meta_keywords }}@endif</textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-lg-3 control-label" for="inputMetaDescription">Meta Description</label>
                                        <div class="col-lg-8">
                                            <textarea name="meta-description" class="form-control" id="inputMetaDescription" rows="3" placeholder="Meta Description">@if ($view_type == 'edit-category'){{ $category_details->meta_description }}@endif</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div id="category-products" class="tab-pane">
                                    @if ($view_type == 'create-new-subcategory')
                                        <div class="well text-center">Save category to see product list</div>
                                    @elseif ($view_type == 'edit-category')
                                        <div class="panel panel-visible" id="spy1">
                                            <div class="panel-body pn">
                                                <table class="table" id="datatable" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th class="text-center">ID</th>
                                                            <th>Product Title</th>
                                                            <th>Product Type</th>
                                                            <th class="text-center">Option</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    @foreach (DB::table('catalog_products as t1')->join('catalog_product_categories as t2', 't1.id', '=', 't2.product_id')->where('t2.category_id', $category_details->id)->select('*', 't1.id as id')->get() as $product)
                                                        <tr>
                                                            <td class="text-center">{{ $product->id }}</td>
                                                            <td>{{ $product->title }}</td>
                                                            <td>{{ $mycatalog->change_product_type($product->type) }}</td>
                                                            @if ($product->type == '1')
                                                                <td class="text-center"><a class="btn btn-primary btn-sm" href="{{ url('admin/catalog/manage-products/edit-simple-product/' . $product->id) }}" target="_blank">Edit</a></td>
                                                            @elseif ($product->type == '2')
                                                                <td class="text-center"><a class="btn btn-primary btn-sm" href="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id) }}" target="_blank">Edit</a></td>
                                                            @endif
                                                        </tr>
                                                    @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- end: .tray-center -->

</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript" src="{{ url('vendor/plugins/datatables/media/js/jquery.dataTables.js') }}"></script>
<script type="text/javascript" src="{{ url('vendor/plugins/datatables/media/js/dataTables.bootstrap.js') }}"></script>
<script type="text/javascript">
    $(document).ready( function() {
        // Init Datatables with Tabletools Addon
        $('#datatable').dataTable({
            "order": [ 0, 'desc' ],
            "aoColumnDefs": [{
                'bSortable': false,
                'aTargets': [-1]
            }],
            "iDisplayLength": 10,
            "aLengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, "All"]
            ],
            "sDom": '<"dt-panelmenu clearfix"lfr>t<"dt-panelfooter clearfix"ip>',
            "oTableTools": {
                "sSwfPath": "{{ url('vendor/plugins/datatables/extensions/TableTools/swf/copy_csv_xls_pdf.swf') }}"
            }
        });

        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var default_permalink = '@if ($view_type == 'edit-category'){{ $category_details->permalink }}@endif';

        $('#inputStatus').multiselect();

        $('#inputPermalink').keyup(function(event) {
            var permalink = $(this).val();
            if (permalink != default_permalink) {
                $.post('{{ url('admin/catalog/manage-categories/api') }}', {_token: CSRF_TOKEN, action: 'check-permalink', permalink: permalink}, function(result) {
                    if(result == '1') {
                        $('#inputPermalinkAlert').html('');
                    } else {
                        $('#inputPermalinkAlert').html('<div class="alert alert-danger alert-sm mt10"><b>Error:</b> Permalink is not available!</div>');
                    }
                });
            } else {
                $('#inputPermalinkAlert').html('');
            }
        });

        $('.btn-delete').click(function() {
            var x;
            if (confirm("Are you sure? you want to delete category? This couldn't undo.") == true) {

            } else {
                return false;
            }
        })

    });
</script>
@endpush
