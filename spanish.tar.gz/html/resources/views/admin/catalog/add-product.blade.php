@extends('layouts.admin')

@push('stylesheet')
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/catalog/manage-products/add-product') }}">Add Product</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/catalog/manage-products') }}">Manage Products</a>
            </li>
            <li class="crumb-trail">Add Product</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/catalog/manage-products') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">
    <form class="form-horizontal" role="form" action="{{ url('admin/catalog/manage-products/add-product') }}" method="post">
        {{ csrf_field() }}
        <div class="panel" style="width: 600px; margin: auto;">
            <div class="panel-heading">Create Product Settings</div>
            <div class="panel-body">
                <div class="form-group">
                    <label for="inputProductType" class="col-lg-3 control-label">Product Type</label>
                    <div class="col-lg-8">
                        <select id="inputProductType" name="product-type" required="required">
                            <option value="simple-product">Simple Product</option>
                            <option value="configurable-product">Configurable Product</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-lg-8 col-lg-offset-3">
                        <input class="btn btn-primary" type="submit" name="submit" value="Submit">
                    </div>
                </div>
            </div>
        </div>
    </form>
</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript">
    $(document).ready(function() {
        $('#inputProductType').multiselect();
    });
</script>

@endpush