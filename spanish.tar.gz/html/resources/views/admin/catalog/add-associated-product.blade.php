@extends('layouts.admin')

@push('stylesheet')
<link rel="stylesheet" type="text/css" href="{{ url('assets/admin-tools/admin-forms/css/admin-forms.css') }}">
<style>
    .form-control[type="radio"] {
        margin: 0;
        height: 20px;
    }
    img[src=""] {
        display: block;
        width: 100%;
        height: 39px;
        font-size: 13px;
        line-height: 1.5;
        color: #555555;
        background-color: #ffffff;
        background-image: none;
        border-radius: 0px;
        -webkit-transition: border-color ease-in-out .15s;
        -o-transition: border-color ease-in-out .15s;
        transition: border-color ease-in-out .15s;
    }
</style>
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id . '/add-associated-product') }}">Add Associated Product</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/catalog/manage-products') }}">Manage Products</a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id) }}">Edit Configurable Product</a>
            </li>
            <li class="crumb-trail">Add Associated Product</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id . '#associated-products') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">
    <form id="form" class="form-horizontal" role="form" action="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id . '/add-associated-product') }}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="panel">
            <div class="panel-body text-right">
                <h4 class="pull-left">Create new associated product under <b>"{{ $product->title }}"</b></h4>
                <a class="btn btn-warning btn-sm" href="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id . '/add-associated-product') }}">Reset</a>
                <input class="btn btn-success btn-sm submit-btn" type="submit" name="submit" value="Save Associated Product">
                <input class="btn btn-success btn-sm submit-btn" type="submit" name="submit" value="Save Associated Product & Continue Edit">
            </div>
        </div>

        @if (Session::has('error-alert'))
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
            </div>
        @elseif (Session::has('success-alert'))
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
            </div>
        @endif

        <div class="panel">
            <div class="panel-heading">
                <ul class="nav panel-tabs-border panel-tabs">
                    <li class="active">
                        <a href="#attribute-information" data-toggle="tab">Attribute Information</a>
                    </li>
                    <li>
                        <a href="#images" data-toggle="tab">Images</a>
                    </li>
                </ul>
            </div>
            <div class="panel-body">
                <div class="tab-content pn br-n">
                    <div id="attribute-information" class="tab-pane active">
                        @foreach (DB::table('catalog_attributes')->orderBy('id')->get() as $attribute)
                            <div class="form-group">
                                <label for="inputAttribute{{ $attribute->title }}" class="col-lg-3 control-label">Attribute {{ $attribute->title }}</label>
                                <div class="col-lg-8">
                                    @if ($attribute->type == 'textfield')
                                        @if ($attribute->title == 'Price')
                                            <span class="append-icon left"><i class="fa fa-usd"></i></span>
                                            <input type="text" name="attribute-{{ $attribute->id }}" class="form-control" id="inputAttribute{{ $attribute->title }}" placeholder="{{ $attribute->title }}" value="{{ $attribute->textfield }}">
                                        @elseif ($attribute->title == 'Discount' || $attribute->title == 'Tax')
                                            <span class="append-icon right">%</span>
                                            <input type="text" name="attribute-{{ $attribute->id }}" class="form-control" id="inputAttribute{{ $attribute->title }}" placeholder="{{ $attribute->title }}" value="{{ $attribute->textfield }}">
                                        @else
                                            <input type="text" name="attribute-{{ $attribute->id }}" id="inputAttribute{{ $attribute->title }}" class="form-control" placeholder="{{ $attribute->title }}" value="{{ $attribute->textfield }}">
                                        @endif
                                    @elseif ($attribute->type == 'textarea')
                                        <textarea id="inputAttribute{{ $attribute->title }}" class="form-control" name="attribute-{{ $attribute->id }}" placeholder="{{ $attribute->title }}">{{ $attribute->textarea }}</textarea>
                                    @elseif ($attribute->type == 'dropdown')
                                        <select id="inputAttribute{{ $attribute->title }}" class="form-control" name="attribute-{{ $attribute->id }}">
                                            <option value="">Select option</option>
                                            @foreach (DB::table('catalog_attribute_options')->where('attribute_id', $attribute->id)->orderBy('order')->get() as $option)
                                                <option value="{{ $option->id }}">{{ $option->admin_value }}</option>
                                            @endforeach
                                        </select>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div id="images" class="tab-pane">
                        <a id="add-image" class="btn btn-primary"><i class="fa fa-plus"></i> Add Image</a>
                        <span class="pull-right mt10">[ Every image must be at least 512x512 px ]</span>
                        <table class="table table-bordered table-images mt15">
                            <thead>
                                <tr class="system">
                                    <th>Image Title</th>
                                    <th class="text-center">Default</th>
                                    <th style="width: 100px;">Order</th>
                                    <th class="text-center">Image</th>
                                    <th>Select Image</th>
                                    <th class="text-center" style="width: 100px;">Option</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><input class="form-control" type="text" name="image-title[]"></td>
                                    <td><input class="input-image-default" type="hidden" name="image-default[]" value="1"><input class="form-control image-default-radio" type="radio" name="image-default-radio" checked="checked"></td>
                                    <td><input class="form-control" type="text" name="image-order[]"></td>
                                    <td class="text-center"><img src="" alt="No Img"></td>
                                    <td><input class="form-control" type="file" name="image[]"></td>
                                    <td class="text-center"><a class="btn btn-danger btn-delete-image" href="#"><i class="fa fa-close"></i> Delete</a></td>
                                </tr>
                            </tbody>
                        </table>

                        <ul class="mt15">
                            <li>Icon: 64x64 px</li>
                            <li>Small image: 64 px width</li>
                            <li>Medium image: 256 px width</li>
                            <li>Large image: 512 px width</li>
                            <li>And one orgianl image</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div
    </form>
    <span id="showAlert"></span>
</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript">
    $(document).ready(function() {
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

        $('#inputStatus').multiselect();
        $('#inputAttributeColor').multiselect();
        $('#inputAttributeSize').multiselect();

        $('#inputAttributeColor, #inputAttributeSize').change(function() {
            check_associated_product();
        });

        function check_associated_product() {
            var product_id = '{{ $product->id }}';
            var color = $('#inputAttributeColor').val();
            var size = $('#inputAttributeSize').val();
            $.post('{{ url('admin/catalog/manage-products/api') }}', {_token: CSRF_TOKEN, action: 'check-associated-product', product_id: product_id, color: color, size: size}, function(result) {
                if(result == '1') {
                    $('#showAlert').html('');
                    $('.submit-btn').removeAttr('disabled');
                } else {
                    $('#showAlert').html('<div class="alert alert-danger alert-sm mt10"><b>Error:</b> Combination of Color & Size already exists!</div>');
                    $('.submit-btn').attr('disabled');
                }
            });
        }
        check_associated_product();



        $(document).on('click', '.btn-delete-image', function() {
            $(this).parent('td').parent('tr').remove();
            return false;
        });

        $(document).on('click', '.image-default-radio', function() {
            $('.input-image-default').val('0');
            $(this).parent('td').children('.input-image-default').val('1');
        });

        $(document).on('click', '#add-image', function() {
            $('.table-images').children('tbody').prepend('<tr><td><input class="form-control" type="text" name="image-title[]"></td><td><input class="input-image-default" type="hidden" name="image-default[]" value="0"><input class="form-control image-default-radio" type="radio" name="image-default-radio"></td><td><input class="form-control" type="text" name="image-order[]"></td><td class="text-center"><img src="" alt="No Img"></td><td><input class="form-control" type="file" name="image[]"></td><td class="text-center"><a class="btn btn-danger btn-delete-image" href="#"><i class="fa fa-close"></i> Delete</a></td></tr>');
            return false;
        });

    });
</script>

@endpush
