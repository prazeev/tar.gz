@extends('layouts.admin')

@push('stylesheet')
<style type="text/css">
    .img-swatches {
        width: 46px;
        height: 46px;
        padding: 2px;
        border: solid 1px #ccc;
    }

    img[src=""] {
        display: block;
        width: 100%;
        height: 39px;
        font-size: 13px;
        line-height: 1.5;
        color: #555555;
        background-color: #ffffff;
        background-image: none;
        border-radius: 0px;
        -webkit-transition: border-color ease-in-out .15s;
        -o-transition: border-color ease-in-out .15s;
        transition: border-color ease-in-out .15s;
    }
</style>
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/catalog/manage-attributes/edit-attribute/' . $attribute_id) }}">Edit Attribute</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/catalog/manage-attributes') }}">Manage Attributes</a>
            </li>
            <li class="crumb-trail">Edit Attribute</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/catalog/manage-attributes') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">

    <form class="form-horizontal" role="form" action="{{ url('admin/catalog/manage-attributes/edit-attribute/'.$attribute_id) }}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="panel">
            <div class="panel-body text-right">
                <h4 class="pull-left">Edit: {{ $attribute->title }}</h4>
                <a class="btn btn-warning btn-sm" href="{{ url('admin/catalog/manage-attributes/edit-attribute/'.$attribute_id) }}">Reset</a>
                <a class="btn btn-danger btn-sm btn-delete" href="{{ url('admin/catalog/manage-attributes/'.$attribute->id.'/delete') }}">Delete</a>
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Attribute">
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Attribute & Continue Edit">
            </div>
        </div>

        @if (Session::has('error-alert'))
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
            </div>
        @elseif (Session::has('success-alert'))
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
            </div>
        @endif

        <div class="panel">
            <div class="panel-heading">
                <ul class="nav panel-tabs-border panel-tabs">
                    <li class="active">
                        <a href="#peroperties" data-toggle="tab">Properties</a>
                    </li>
                    <li>
                        <a href="#frontend" data-toggle="tab">Frontend</a>
                    </li>
                    <li>
                        <a href="#options" data-toggle="tab">Options</a>
                    </li>
                </ul>
            </div>
            <div class="panel-body">
                <div class="tab-content pn br-n">
                    <div id="peroperties" class="tab-pane active">
                        <div class="form-group">
                            <label for="inputTitle" class="col-lg-3 control-label">Attribute Title</label>
                            <div class="col-lg-8">
                                <input type="text" name="title" id="inputTitle" class="form-control" placeholder="Attribute Title" required="required" value="{{ $attribute->title }}">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputType" class="col-lg-3 control-label">Attribute Type</label>
                            <div class="col-lg-8">
                                <select id="inputType" name="type" required="required">
                                    <option value="{{ $attribute->type }}" selected="selected">{{ $mycatalog->change_attribute_type($attribute->type) }}</option>
                                </select>
                            </div>
                        </div>
                        @if ($attribute->type == 'textfield')
                        <div class="form-group">
                            <label for="inputDefault" class="col-lg-3 control-label">Default Value</label>
                            <div class="col-lg-8">
                                <input type="text" name="textfield-default" id="inputDefault" class="form-control" placeholder="Default Value" value="{{ $attribute->textfield }}">
                            </div>
                        </div>
                        @elseif ($attribute->type == 'textarea')
                        <div class="form-group" style="display: none;">
                            <label for="inputDefault" class="col-lg-3 control-label">Default Value</label>
                            <div class="col-lg-8">
                                <textarea id="inputDefault" class="form-control" name="textarea-default" placeholder="Default Value">{{ $attribute->textarea }}</textarea>
                            </div>
                        </div>
                        @endif
                    </div>
                    <div id="frontend" class="tab-pane">
                        <div class="form-group">
                            <label class="col-lg-3 control-label">Use in Quick Search</label>
                            <div class="col-lg-8">
                                <select id="inputQuickSearch" name="quick-search" required="required">
                                    <option value="1" @if ($attribute->quick_search == '1') selected="selected" @endif>Yes</option>
                                    <option value="0" @if ($attribute->quick_search == '0') selected="selected" @endif>No</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-3 control-label">Use in Advanced Search</label>
                            <div class="col-lg-8">
                                <select id="inputAdvanceSearch" name="advance-search" required="required">
                                    <option value="1" @if ($attribute->advance_search == '1') selected="selected" @endif>Yes</option>
                                    <option value="0" @if ($attribute->advance_search == '0') selected="selected" @endif>No</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div id="options" class="tab-pane">
                        @if ($attribute->type != 'dropdown')
                        <div class="well text-center no-option-needed">No option needed</div>
                        @elseif ($attribute->type == 'dropdown')
                        <div class="form-group">
                            <label class="col-lg-3 control-label">Enable Swatches</label>
                            <div class="col-lg-8">
                                <select id="inputSwatches" name="swatches">
                                    <option value="1" @if ($attribute->swatches == '1') selected="selected" @endif>Yes</option>
                                    <option value="0" @if ($attribute->swatches == '0') selected="selected" @endif>No</option>
                                </select>
                                <a id="add-option" class="btn btn-primary ml10"><i class="fa fa-plus"></i> Add Option</a>
                                <span class="pull-right mt10 about-swatches-info" @if ($attribute->swatches == '0') style="display: none;" @endif>[ Every swatches must be 140x140 px ]</span>
                            </div>
                        </div>
                        <table class="table table-bordered table-options">
                            <thead>
                                <tr class="system">
                                    <th>Admin Value</th>
                                    <th>Store Value</th>
                                    <th style="width: 100px;">Order</th>
                                    <th class="text-center td-swatches" @if ($attribute->swatches == '0') style="display: none;" @endif>Swatches</th>
                                    <th class="td-swatches" @if ($attribute->swatches == '0') style="display: none;" @endif>Select Image</th>
                                    <th class="text-center" style="width: 100px;">Option</th>
                                </tr>
                            </thead>
                            <tbody>
                            @foreach (DB::table('catalog_attribute_options')->where('attribute_id', $attribute_id)->orderBy('order', 'desc')->get() as $attribute_option)
                                <tr>
                                    <input type="hidden" name="option-id[]" value="{{ $attribute_option->id }}">
                                    <td><input class="form-control" type="text" name="option-admin-value[]" value="{{ $attribute_option->admin_value }}"></td>
                                    <td><input class="form-control" type="text" name="option-store-value[]" value="{{ $attribute_option->store_value }}"></td>
                                    <td><input class="form-control" type="text" name="option-order[]" value="{{ $attribute_option->order }}"></td>
                                    <td class="text-center td-swatches" @if ($attribute->swatches == '0') style="display: none;" @endif><img class="img-swatches" src="{{ url('storage/'.$attribute_option->swatche) }}" alt="No Img"></td>
                                    <td class="td-swatches" @if ($attribute->swatches == '0') style="display: none;" @endif><input class="form-control" type="file" name="image[]"></td>
                                    <td class="text-center"><a class="btn btn-danger btn-delete-swatches" href="#"><i class="fa fa-close"></i> Delete</a></td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </form>

</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript">
    $(document).ready(function() {

        $('#inputType').multiselect();
        $('#inputQuickSearch').multiselect();
        $('#inputAdvanceSearch').multiselect();
        $('#inputSwatches').multiselect();

        $(document).on('change', '#inputType', function(event) {
            var val = $(this).val();
            if(val == 'textfield') {
                $('.swatches').hide('slow');
                $('.textarea-default').hide('slow');
                $('.no-option-needed').show('slow');
                $('.textfield-default').show('slow');
            } else if(val == 'textarea') {
                $('.swatches').hide('slow');
                $('.textfield-default').hide('slow');
                $('.no-option-needed').show('slow');
                $('.textarea-default').show('slow');
            } else if(val == 'dropdown') {
                $('.textfield-default').hide('slow');
                $('.textarea-default').hide('slow');
                $('.no-option-needed').hide('slow');
                $('.swatches').show('slow');
                $('.table-options').show('slow');
            }

        });

        $(document).on('change', '#inputSwatches', function() {
            var val = $(this).val();
            if(val == '1') {
                $('.td-swatches').fadeIn('slow');
                $('.about-swatches-info').fadeIn('slow');
            } else if (val == '0') {
                $('.td-swatches').fadeOut('slow');
                $('.about-swatches-info').fadeOut('slow');
            }
        });

        $(document).on('click', '.btn-delete-swatches', function() {
            $(this).parent('td').parent('tr').remove();
            return false;
        });

        $(document).on('click', '#add-option', function() {
            var inputSwatches = $('#inputSwatches').val();
            if(inputSwatches == '1') {
                $('.table-options').children('tbody').prepend('<tr><input type="hidden" name="option-id[]" value=""><td><input class="form-control" type="text" name="option-admin-value[]"></td><td><input class="form-control" type="text" name="option-store-value[]"></td><td><input class="form-control" type="text" name="option-order[]"></td><td class="text-center td-swatches"><img class="img-swatches" src="" alt="No Img"></td><td class="td-swatches"><input class="form-control" type="file" name="image[]"></td><td class="text-center"><a class="btn btn-danger btn-delete-swatches" href="#"><i class="fa fa-close"></i> Delete</a></td></tr>');
            } else if(inputSwatches == '0') {
                $('.table-options').children('tbody').prepend('<tr><input type="hidden" name="option-id[]" value=""><td><input class="form-control" type="text" name="option-admin-value[]"></td><td><input class="form-control" type="text" name="option-store-value[]"></td><td><input class="form-control" type="text" name="option-order[]"></td><td class="text-center td-swatches" style="display: none;"><img class="img-swatches" src="" alt="No Img"></td><td class="td-swatches" style="display: none;"><input class="form-control" type="file" name="image[]"></td><td class="text-center"><a class="btn btn-danger btn-delete-swatches" href="#"><i class="fa fa-close"></i> Delete</a></td></tr>');
            }
            return false;
        });

        $('.btn-delete').click(function () {
            var x;
            if (confirm("Are you sure? you want to delete Attribute? This couldn't undo.") == true) {

            } else {
                return false;
            }
        });

    });
</script>

@endpush
