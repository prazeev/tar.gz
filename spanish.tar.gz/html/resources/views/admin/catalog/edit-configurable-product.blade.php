@extends('layouts.admin')

@push('stylesheet')
<link rel="stylesheet" type="text/css" href="{{ url('vendor/plugins/datatables/media/css/dataTables.bootstrap.css') }}">
<link rel="stylesheet" type="text/css" href="{{ url('assets/admin-tools/admin-forms/css/admin-forms.css') }}">
<style>
    .form-control[type="radio"] {
        margin: 0;
        height: 20px;
    }
    img[src=""] {
        display: block;
        width: 100%;
        height: 39px;
        font-size: 13px;
        line-height: 1.5;
        color: #555555;
        background-color: #ffffff;
        background-image: none;
        border-radius: 0px;
        -webkit-transition: border-color ease-in-out .15s;
        -o-transition: border-color ease-in-out .15s;
        transition: border-color ease-in-out .15s;
    }
</style>
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id) }}">Edit Configurable Product</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/catalog/manage-products') }}">Manage Products</a>
            </li>
            <li class="crumb-trail">Edit Configurable Product</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/catalog/manage-products') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">
    <form class="form-horizontal" role="form" action="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id) }}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="panel">
            <div class="panel-body text-right">
                <h4 class="pull-left">Edit: {{ $product->title }}</h4>
                <a class="btn btn-warning btn-sm" href="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id) }}">Reset</a>
                <a class="btn btn-danger btn-sm btn-delete" href="{{ url('admin/catalog/manage-products/' . $product->id . '/delete') }}">Delete</a>
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Product">
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Product & Continue Edit">
            </div>
        </div>

        @if (Session::has('error-alert'))
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
            </div>
        @elseif (Session::has('success-alert'))
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
            </div>
        @endif

        <div class="panel">
            <div class="panel-heading">
                <ul class="nav panel-tabs-border panel-tabs">
                    <li class="active">
                        <a href="#general-information" data-toggle="tab">General Information</a>
                    </li>
                    <li>
                        <a href="#meta-information" data-toggle="tab">Meta Information</a>
                    </li>
                    <li>
                        <a href="#categories" data-toggle="tab">Categories</a>
                    </li>
                    <li>
                        <a href="#associated-products" data-toggle="tab">Associated Products</a>
                    </li>
                </ul>
            </div>
            <div class="panel-body">
                <div class="tab-content pn br-n">
                    <div id="general-information" class="tab-pane active">
                        <div class="form-group">
                            <label for="inputTitle" class="col-lg-3 control-label">Product Title</label>
                            <div class="col-lg-8">
                                <input type="text" name="title" id="inputTitle" class="form-control" placeholder="Product Title" required="required" value="{{ $product->title }}">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputStatus" class="col-lg-3 control-label">Status</label>
                            <div class="col-lg-8">
                                <select id="inputStatus" name="status" required="required">
                                    <option value="1" @if ($product->status == '1') selected="selected" @endif>Active</option>
                                    <option value="0" @if ($product->status == '0') selected="selected" @endif>Inactive</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group textfield-default">
                            <label for="inputPermalink" class="col-lg-3 control-label">Permalink</label>
                            <div class="col-lg-8">
                                <input type="text" name="permalink" id="inputPermalink" class="form-control" placeholder="Permalink" required="required" value="{{ $product->permalink }}">
                                <span id="inputPermalinkAlert"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputTagline" class="col-lg-3 control-label">Product Tagline</label>
                            <div class="col-lg-8">
                                <textarea id="inputTagline" class="form-control" name="tagline" placeholder="Tagline">{{ $product->tagline }}</textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputDescription" class="col-lg-3 control-label">Product Description</label>
                            <div class="col-lg-8">
                                <textarea id="inputDescription" class="form-control" name="description" placeholder="Description" rows="5">{{ $product->description }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div id="meta-information" class="tab-pane">
                        <div class="form-group">
                            <label for="inputMetaTitle" class="col-lg-3 control-label">Meta Title</label>
                            <div class="col-lg-8">
                                <input type="text" name="meta-title" id="inputMetaTitle" class="form-control" placeholder="Meta Title" value="{{ $product->meta_title }}">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputMetaKeywords" class="col-lg-3 control-label">Meta Keywords</label>
                            <div class="col-lg-8">
                                <textarea id="inputMetaKeywords" class="form-control" name="meta-keywords" placeholder="Meta Keywords">{{ $product->meta_keywords }}</textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputMetaDescription" class="col-lg-3 control-label">Meta Description</label>
                            <div class="col-lg-8">
                                <textarea id="inputMetaDescription" class="form-control" name="meta-description" placeholder="Meta Description">{{ $product->meta_description }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div id="categories" class="tab-pane">
                        <h4 class="mt5 mb20">Categories</h4>
                        <ul class="list-unstyled">
                        @foreach (DB::table('catalog_categories')->where('parent','0')->get() as $category0)
                            <li>
                                <label><input type="checkbox" name="categories[]" value="{{ $category0->id }}" @if (DB::table('catalog_product_categories')->where('product_id', $product->id)->where('category_id', $category0->id)->count() == 1) checked="checked" @endif> <i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category0->title }}</label>
                            @if (DB::table('catalog_categories')->where('parent', $category0->id)->count() > 0)
                                <ul class="list-unstyled  ml20">
                                @foreach (DB::table('catalog_categories')->where('parent', $category0->id)->get() as $category1)
                                    <li>
                                    <label><input type="checkbox" name="categories[]" value="{{ $category1->id }}" @if (DB::table('catalog_product_categories')->where('product_id', $product->id)->where('category_id', $category1->id)->count() == 1) checked="checked" @endif> <i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category1->title }}</label>
                                    @if (DB::table('catalog_categories')->where('parent', $category1->id)->count() > 0)
                                        <ul class="list-unstyled  ml20">
                                        @foreach (DB::table('catalog_categories')->where('parent', $category1->id)->get() as $category2)
                                            <li>
                                                <label><input type="checkbox" name="categories[]" value="{{ $category2->id }}" @if (DB::table('catalog_product_categories')->where('product_id', $product->id)->where('category_id', $category2->id)->count() == 1) checked="checked" @endif> <i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category2->title }}</label>
                                            @if (DB::table('catalog_categories')->where('parent', $category2->id)->count() > 0)
                                                <ul class="list-unstyled  ml20">
                                                @foreach (DB::table('catalog_categories')->where('parent', $category2->id)->get() as $category3)
                                                    <li>
                                                        <label><input type="checkbox" name="categories[]" value="{{ $category3->id }}" @if (DB::table('catalog_product_categories')->where('product_id', $product->id)->where('category_id', $category3->id)->count() == 1) checked="checked" @endif> <i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category3->title }}</label>
                                                    @if (DB::table('catalog_categories')->where('parent', $category3->id)->count() > 0)
                                                        <ul class="list-unstyled  ml20">
                                                        @foreach (DB::table('catalog_categories')->where('parent', $category3->id)->get() as $category4)
                                                            <li>
                                                                <label><input type="checkbox" name="categories[]" value="{{ $category4->id }}" @if (DB::table('catalog_product_categories')->where('product_id', $product->id)->where('category_id', $category4->id)->count() == 1) checked="checked" @endif> <i class="fa fa-folder-o text-warning fa-lg mr5"></i> {{ $category4->title }}</label>
                                                            </li>
                                                        @endforeach
                                                        </ul>
                                                    @endif
                                                    </li>
                                                @endforeach
                                                </ul>
                                            @endif
                                            </li>
                                        @endforeach
                                        </ul>
                                    @endif
                                    </li>
                                @endforeach
                                </ul>
                            @endif
                            </li>
                        @endforeach
                        </ul>
                    </div>
                    <div id="associated-products" class="tab-pane">
                        <a class="btn btn-primary" href="{{ url('admin/catalog/manage-products/edit-configurable-product/'. $product->id . '/add-associated-product') }}"><i class="fa fa-plus mr5"></i> Add Associated Product</a>
                        <div class="pt15"><div>
                        <table class="table table-striped table-hover" id="datatable" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th class="text-center">ID</th>
                                    @foreach (DB::table('catalog_attributes')->get() as $attribute)
                                        @if ($attribute->title == 'Color')
                                            <th class="text-center">{{ $attribute->title }}</th>
                                        @endif
                                        @if ($attribute->title == 'Size')
                                            <th class="text-center">{{ $attribute->title }}</th>
                                        @endif
                                        @if ($attribute->title == 'Price')
                                            <th class="text-center">{{ $attribute->title }}</th>
                                        @endif
                                        @if ($attribute->title == 'Discount')
                                            <th class="text-center">{{ $attribute->title }}</th>
                                        @endif
                                        @if ($attribute->title == 'Stock')
                                            <th class="text-center">{{ $attribute->title }}</th>
                                        @endif
                                    @endforeach
                                    <th class="text-center">Default</th>
                                    <th class="text-center" style="width: 100px;">Option</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach (DB::table('catalog_product_associated_products')->where('product_id', $product->id)->get() as $associated_product)
                                    <tr>
                                        <input type="hidden" name="associated-product-id[]" value="{{ $associated_product->id }}">
                                        <td class="text-center">{{ $associated_product->id }}</td>
                                        @foreach (DB::table('catalog_product_attributes')->leftJoin('catalog_attributes', 'catalog_product_attributes.attribute_id', '=', 'catalog_attributes.id')->where('catalog_product_attributes.product_id', $product->id)->where('catalog_product_attributes.associated_product_id', $associated_product->id)->get() as $attribute)

                                            @if ($attribute->title == 'Color')
                                                <td class="text-center">{{ DB::table('catalog_attribute_options')->where('attribute_id', $attribute->attribute_id)->where('id', $attribute->attribute_option_id)->first()->admin_value }}</td>
                                            @endif
                                            @if ($attribute->title == 'Size')
                                                <td class="text-center">{{ DB::table('catalog_attribute_options')->where('attribute_id', $attribute->attribute_id)->where('id', $attribute->attribute_option_id)->first()->admin_value }}</td>
                                            @endif
                                            @if ($attribute->title == 'Price')
                                                <td class="text-center">{{ $attribute->attribute_value }}</td>
                                            @endif
                                            @if ($attribute->title == 'Discount')
                                                <td class="text-center">{{ $attribute->attribute_value }} %</td>
                                            @endif
                                            @if ($attribute->title == 'Stock')
                                                <td class="text-center">{{ $attribute->attribute_value }}</td>
                                            @endif

                                        @endforeach
                                        <td class="text-center"><input class="input-associated-product-default" type="hidden" name="associated-product-default[]" @if ($associated_product->product_default == '1') value="1" @else value="0" @endif><input class="form-control associated-product-default-radio" type="radio" name="associated-product-default-radio" @if ($associated_product->product_default == '1') checked="checked" @endif></td>
                                        <td class="text-center"><a class="btn btn-primary btn-sm" href="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id . '/edit-associated-product/' . $associated_product->id) }}">Edit</a> <a class="btn btn-danger btn-sm" href="{{ url('admin/catalog/manage-products/edit-configurable-product/' . $product->id . '/' . $associated_product->id . '/delete') }}">Delete</a></td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div
    </form>
</section>
<!-- End: Content -->

@endsection

@push('javascript')
<script type="text/javascript" src="{{ url('vendor/plugins/datatables/media/js/jquery.dataTables.js') }}"></script>
<script type="text/javascript" src="{{ url('vendor/plugins/datatables/media/js/dataTables.bootstrap.js') }}"></script>
<script type="text/javascript">
    $(document).ready(function() {

        // Init Datatables with Tabletools Addon
        $('#datatable').dataTable({
            "order": [ 0, 'desc' ],
            "aoColumnDefs": [{
                'bSortable': false,
                'aTargets': [-1]
            }],
            "iDisplayLength": 25,
            "aLengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, "All"]
            ],
            "sDom": '<"dt-panelmenu clearfix"lfr>t<"dt-panelfooter clearfix"ip>',
            "oTableTools": {
                "sSwfPath": "{{ url('vendor/plugins/datatables/extensions/TableTools/swf/copy_csv_xls_pdf.swf') }}"
            }
        });

        $(document).on('click', '.associated-product-default-radio', function() {
            $('.input-associated-product-default').val('0');
            $(this).parent('td').children('.input-associated-product-default').val('1');
        });

        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var default_permalink = '{{ $product->permalink }}';

        $('#inputStatus').multiselect();
        $('#inputAttributeColor').multiselect();
        $('#inputAttributeSize').multiselect();

        $('#inputPermalink').keyup(function(event) {
            var permalink = $(this).val();
            if (permalink != default_permalink) {
                $.post('{{ url('admin/catalog/manage-products/api') }}', {_token: CSRF_TOKEN, action: 'check-permalink', permalink: permalink}, function(result) {
                    if(result == '1') {
                        $('#inputPermalinkAlert').html('');
                    } else {
                        $('#inputPermalinkAlert').html('<div class="alert alert-danger alert-sm mt10"><b>Error:</b> Permalink is not available!</div>');
                    }
                });
            } else {
                $('#inputPermalinkAlert').html('');
            }
        });

        $('.btn-delete').click(function () {
            var x;
            if (confirm("Are you sure? you want to delete Product? This couldn't undo.") == true) {

            } else {
                return false;
            }
        });

    });
</script>

@endpush
