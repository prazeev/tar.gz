@extends('layouts.admin')

@push('stylesheet')
<style type="text/css" media="screen">
.ace_editor {
    border: 1px solid lightgray;
    margin: auto;
    width: 100%;
    height: 80vh;
    font-size: 14px !important;
}
.scrollmargin {
    height: 80px;
    text-align: center;
}
</style>
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/manage-staticblocks/add-staticblock') }}">Add Staticblock</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/manage-staticblocks') }}">Manage Staticblocks</a>
            </li>
            <li class="crumb-trail">Add Staticblock</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/manage-staticblocks') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">
    <form class="form-horizontal" role="form" action="{{ url('admin/manage-staticblocks/add-staticblock') }}" method="post">
        {{ csrf_field() }}
        <div class="panel">
            <div class="panel-body text-right">
                <h4 class="pull-left">Create new Staticblock</h4>
                <a class="btn btn-warning btn-sm" href="{{ url('admin/manage-pages/add-staticblock') }}">Reset</a>
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Staticblock">
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Staticblock & Continue Edit">
            </div>
        </div>

        @if (Session::has('error-alert'))
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
            </div>
        @elseif (Session::has('success-alert'))
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
            </div>
        @endif

        <div class="panel">
            <div class="panel-heading">Staticblock Details</div>
            <div class="panel-body">
                <label for="inputTitle">Staticblock Title</label>
                <input id="inputTitle" class="form-control" type="text" name="title" placeholder="Staticblock Title" required="required">
                <br>
                <label for="inputContent">Staticblock Content</label>
                <textarea id="inputContent" class="form-control" rows="16" name="content" style="display: none;"></textarea>
                <textarea id="codeContent" class="form-control" rows="16"></textarea>
            </div>
        </div>
    </form>
</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript" src="{{ url('assets/plugins/ace/ace.js') }}"></script>
<script type="text/javascript" src="{{ url('assets/plugins/ace/textarea/src/ace-bookmarklet.js') }}"></script>
<script type="text/javascript">
jQuery(document).ready(function() {

    var textarea = $('#inputContent');

    var editor = ace.edit("codeContent");
    editor.setTheme("ace/theme/chrome");
    editor.setAutoScrollEditorIntoView(true);
    editor.setOption("minLines", 100);
    editor.setShowPrintMargin(false);
    editor.getSession().setUseWrapMode(true);
    editor.getSession().on('change', function () {
        textarea.val(editor.getSession().getValue());
    });
    textarea.val(editor.getSession().getValue());

    $('.btn-delete').click(function () {
        var x;
        if (confirm("Are you sure? you want to delete Staticblock? This couldn't undo.") == true) {

        } else {
            return false;
        }
    });

});
</script>
@endpush
