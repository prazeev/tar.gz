@extends('layouts.admin')

@push('stylesheet')
<link rel="stylesheet" type="text/css" href="{{ url('vendor/plugins/datatables/media/css/dataTables.bootstrap.css') }}">
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/manage-pages') }}">Manage Pages</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-trail">Manage Pages</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/manage-pages/add-page') }}"><i class="fa fa-plus"></i> Add Page</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">

    @if (Session::has('error-alert'))
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
        </div>
    @elseif (Session::has('success-alert'))
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
        </div>
    @endif

    <div class="panel panel-visible" id="spy1">
        <div class="panel-body pn">
            <table class="table table-striped table-hover" id="datatable" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th class="text-center">ID</th>
                        <th>Page Title</th>
                        <th>Created date</th>
                        <th>Updated date</th>
                        <th class="text-center">Option</th>
                    </tr>
                </thead>
                <tbody>
                @foreach (DB::table('pages')->get() as $page)
                    <tr>
                        <td class="text-center">{{ $page->id }}</td>
                        <td>{{ $page->title }}</td>
                        <td>{{ $page->created_at }}</td>
                        <td>{{ $page->updated_at }}</td>
                        <td class="text-center"><a class="btn btn-primary btn-sm" target="_blank" href="{{ url($page->permalink) }}">View</a> <a class="btn btn-primary btn-sm" href="{{ url('admin/manage-pages/edit-page/'.$page->id) }}">Edit</a> <a class="btn btn-danger btn-sm btn-delete" href="{{ url('admin/manage-pages/'.$page->id.'/delete') }}">Delete</a></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>

</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript" src="{{ url('vendor/plugins/datatables/media/js/jquery.dataTables.js') }}"></script>
<script type="text/javascript" src="{{ url('vendor/plugins/datatables/media/js/dataTables.bootstrap.js') }}"></script>

<script type="text/javascript">
    jQuery(document).ready(function() {

        // Init tray navigation smooth scroll
        $('.tray-nav a').smoothScroll({
            offset: -145
        });

        // Init Datatables with Tabletools Addon
        $('#datatable').dataTable({
            "order": [ 0, 'desc' ],
            "aoColumnDefs": [{
                'bSortable': false,
                'aTargets': [-1]
            }],
            "iDisplayLength": 10,
            "aLengthMenu": [
                [5, 10, 25, 50, 100, -1],
                [5, 10, 25, 50, 100, "All"]
            ],
            "sDom": '<"dt-panelmenu clearfix"lfr>t<"dt-panelfooter clearfix"ip>',
            "oTableTools": {
                "sSwfPath": "{{ url('vendor/plugins/datatables/extensions/TableTools/swf/copy_csv_xls_pdf.swf') }}"
            }
        });

        $('.btn-delete').click(function () {
            var x;
            if (confirm("Are you sure? you want to delete Page? This couldn't undo.") == true) {

            } else {
                return false;
            }
        });

    });
</script>
@endpush
