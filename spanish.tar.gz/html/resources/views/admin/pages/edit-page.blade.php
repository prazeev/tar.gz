@extends('layouts.admin')

@push('stylesheet')
<style type="text/css" media="screen">
.ace_editor {
    border: 1px solid lightgray;
    margin: auto;
    width: 100%;
    height: 80vh;
    font-size: 14px !important;
}
.scrollmargin {
    height: 80px;
    text-align: center;
}
</style>
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/manage-pages/edit-page/' . $page->id) }}">Edit Page</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/manage-pages') }}">Manage Pages</a>
            </li>
            <li class="crumb-trail">Edit Page</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/manage-pages') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">
    <form class="form-horizontal" role="form" action="{{ url('admin/manage-pages/edit-page/' . $page->id) }}" method="post">
        {{ csrf_field() }}
        <div class="panel">
            <div class="panel-body text-right">
                <h4 class="pull-left">Edit: {{ $page->title }}</h4>
                <a class="btn btn-warning btn-sm" href="{{ url('admin/manage-pages/edit-page/' . $page->id) }}">Reset</a>
                <a class="btn btn-danger btn-sm btn-delete" href="{{ url('admin/manage-pages/'.$page->id.'/delete') }}">Delete</a>
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Page">
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Page & Continue Edit">
            </div>
        </div>

        @if (Session::has('error-alert'))
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
            </div>
        @elseif (Session::has('success-alert'))
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
            </div>
        @endif

        <div class="panel">
            <div class="panel-heading">Page Details</div>
            <div class="panel-body">
                <label for="inputTitle">Page Title</label>
                <input id="inputTitle" class="form-control" type="text" name="title" placeholder="Page Title" required="required" value="{{ $page->title }}">
                <br>
                <label for="inputPermalink">Permalink</label>
                <input type="text" name="permalink" id="inputPermalink" class="form-control" placeholder="Permalink" required="required" value="{{ $page->permalink }}">
                <span id="inputPermalinkAlert"></span>
                <br>
                <label for="inputContent">Page Content</label>
                <textarea id="inputContent" class="form-control" rows="16" name="content" style="display: none;">{{ $page->content }}</textarea>
                <textarea id="codeContent" class="form-control" rows="16">{{ $page->content }}</textarea>
            </div>
        </div>
    </form>
</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript" src="{{ url('assets/plugins/ace/ace.js') }}"></script>
<script type="text/javascript" src="{{ url('assets/plugins/ace/textarea/src/ace-bookmarklet.js') }}"></script>
<script type="text/javascript">
    $(document).ready(function() {
        var textarea = $('#inputContent');

        var editor = ace.edit("codeContent");
        editor.setTheme("ace/theme/chrome");
        editor.setAutoScrollEditorIntoView(true);
        editor.setOption("minLines", 100);
        editor.setShowPrintMargin(false);
        editor.getSession().setUseWrapMode(true);
        editor.getSession().on('change', function () {
            textarea.val(editor.getSession().getValue());
        });
        textarea.val(editor.getSession().getValue());

        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $('#inputPermalink').keyup(function(event) {
            var permalink = $(this).val();
            $.post('{{ url('admin/manage-pages/api') }}', {_token: CSRF_TOKEN, action: 'check-permalink', permalink: permalink}, function(result) {
                if(result == '1') {
                    $('#inputPermalinkAlert').html('');
                } else {
                    $('#inputPermalinkAlert').html('<div class="alert alert-danger alert-sm mt10"><b>Error:</b> Permalink is not available!</div>');
                }
            });
        });
        $('.btn-delete').click(function () {
            var x;
            if (confirm("Are you sure? you want to delete Page? This couldn't undo.") == true) {

            } else {
                return false;
            }
        });
    });
</script>
@endpush
