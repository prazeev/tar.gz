@extends('layouts.admin')

@push('stylesheet')
<link rel="stylesheet" type="text/css" href="{{ url('assets/admin-tools/admin-forms/css/admin-forms.css') }}">
<style>
    .form-control[type="radio"] {
        margin: 0;
        height: 20px;
    }
    img[src=""] {
        display: block;
        width: 100%;
        height: 39px;
        font-size: 13px;
        line-height: 1.5;
        color: #555555;
        background-color: #ffffff;
        background-image: none;
        border-radius: 0px;
        -webkit-transition: border-color ease-in-out .15s;
        -o-transition: border-color ease-in-out .15s;
        transition: border-color ease-in-out .15s;
    }
</style>
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/manage-users/edit-user/' . $user->id) }}">Edit User</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/manage-users') }}">Manage Users</a>
            </li>
            <li class="crumb-trail">Edit User</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/manage-users') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">
    <form class="form-horizontal" role="form" action="{{ url('admin/manage-users/edit-user/' . $user->id) }}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="panel">
            <div class="panel-body text-right">
                <h4 class="pull-left">Edit: {{ $user->name }}</h4>
                <a class="btn btn-warning btn-sm" href="{{ url('admin/manage-users/edit-user/' . $user->id) }}">Reset</a>
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save User">
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save User & Continue Edit">
            </div>
        </div>

        @if (Session::has('error-alert'))
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
        </div>
        @elseif (Session::has('success-alert'))
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
        </div>
        @endif

        <div class="well">Working here</div>
        
    </form>
</section>
<!-- End: Content -->
@endsection

@push('javascript')
@endpush
