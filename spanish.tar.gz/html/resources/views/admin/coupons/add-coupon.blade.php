@extends('layouts.admin')

@push('stylesheet')
<style type="text/css" media="screen">
    .ace_editor {
        border: 1px solid lightgray;
        margin: auto;
        width: 100%;
        height: 80vh;
        font-size: 14px !important;
    }
    .scrollmargin {
        height: 80px;
        text-align: center;
    }
</style>
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/manage-coupons/add-coupon') }}">Add Coupon</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-link">
                <a href="{{ url('admin/manage-coupons') }}">Manage Coupons</a>
            </li>
            <li class="crumb-trail">Add Coupon</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/manage-coupons') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">
    <form class="form-horizontal" role="form" action="{{ url('admin/manage-coupons/add-coupon') }}" method="post">
        {{ csrf_field() }}
        <div class="panel">
            <div class="panel-body text-right">
                <h4 class="pull-left">Create new coupon</h4>
                <a class="btn btn-warning btn-sm" href="{{ url('admin/manage-coupons/add-coupon') }}">Reset</a>
                <input class="btn btn-success btn-sm" type="submit" name="submit" value="Save Coupon">
            </div>
        </div>

        @if (Session::has('error-alert'))
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
        </div>
        @elseif (Session::has('success-alert'))
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
        </div>
        @endif

        <div class="panel">
            <div class="panel-heading">Coupon Details</div>
            <div class="panel-body">
                <label for="inputTitle">Coupon Title</label>
                <input id="inputTitle" class="form-control" type="text" name="title" placeholder="Coupon Title" required="required">
                <br>
                <label for="inputCode">Coupon Code</label>
                <input type="text" name="code" id="inputCode" class="form-control" required="required">
                <span id="inputCodeAlert"></span>
                <br>
                <label for="inputCode">Coupon Type</label>
                <br>
                <select id="inputType" name="type" required="required">
                    <option value="single">Single Use</option>
                    <option value="multiple">Multiple Use</option>
                </select>
                <br>
                <br>
                <label for="inputDiscount">Discount Percentage</label>
                <div class="form-group">
                    <div class="col-md-12">
                        <span class="append-icon right">%</span>
                        <input type="text" name="discount" class="form-control" id="inputDiscount" value="0" required="required">
                    </div>
                </div>
            </div>
        </div>
    </form>
</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript">
    $(document).ready(function() {
        $('#inputType').multiselect();
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $('#inputCode').keyup(function(event) {
            var code = $(this).val();
            $.post('{{ url('admin/manage-coupons/api') }}', {_token: CSRF_TOKEN, action: 'check-coupon-code', code: code}, function(result) {
                if(result == '1') {
                    $('#inputCodeAlert').html('');
                } else {
                    $('#inputCodeAlert').html('<div class="alert alert-danger alert-sm mt10"><b>Error:</b> Coupon code already exist! Try another.</div>');
                }
            });
        });
    });
</script>
@endpush
