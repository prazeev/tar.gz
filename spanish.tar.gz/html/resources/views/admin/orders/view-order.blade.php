@extends('layouts.admin')

@push('stylesheet')
<link rel="stylesheet" type="text/css" href="{{ url('vendor/plugins/datatables/media/css/dataTables.bootstrap.css') }}">
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/manage-orders') }}">Orders</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li><a href="{{ url('admin/manage-orders') }}">Orders</a></li>
            <li class="crumb-trail">Order #{{ $checkout->id }}</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/manage-orders') }}"><i class="fa fa-arrow-left"></i> Back</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">

    @if (Session::has('error-alert'))
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
    </div>
    @elseif (Session::has('success-alert'))
    <div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
    </div>
    @endif

    
    <div class="panel invoice-panel">
        <div class="panel-heading">
            <span class="panel-title"><span class="glyphicon glyphicon-list"></span> Order Details</span>
            <div class="panel-header-menu pull-right mr10">
                <a href="javascript:window.print()" class="btn btn-xs btn-default btn-gradient mr5"> <i class="fa fa-print fs13"></i> </a>
            </div>
        </div>
        <div class="panel-body p20" id="invoice-item">

            <div class="row" id="invoice-info">
                <div class="col-md-4">
                    <div class="panel panel-alt">
                        <div class="panel-heading">
                            <span class="panel-title"> <i class="fa fa-user"></i> Customer Details</span>
                        </div>
                        <div class="panel-body">
                            <address>
                                @php ($customer = DB::table('customers')->where('user_id', $checkout->user_id)->first())
                                <strong>{{ $customer->firstname . ' ' . $customer->lastname }} <small>[ID: {{ $customer->user_id }}]</small></strong>
                                <br> {{ $customer->email }}
                                <br> Membership: @if ($customer->verify_code == '') Verified @else Not Verified @endif
                                <br> Member since: {{ date("Y-m-d", strtotime($customer->created_at)) }}
                                <br> Phone: {{ $customer->phone }}
                            </address>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-alt">
                        <div class="panel-heading">
                            <span class="panel-title"> <i class="fa fa-location-arrow"></i> Shipping Details</span>
                        </div>
                        <div class="panel-body">
                            <address>
                                <strong>{{ $checkout->shipping_name }}</strong>
                                <br> {{ $checkout->shipping_email }}
                                <br> {{ $checkout->shipping_address }}
                                <br> {{ $checkout->shipping_address_alt }}
                                <br> Postal Code: {{ $checkout->shipping_postal_code }}
                                <br> Phone: {{ $checkout->shipping_phone }}
                            </address>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-alt">
                        <div class="panel-heading">
                            <span class="panel-title"> <i class="fa fa-info"></i> Order Details </span>
                        </div>
                        <div class="panel-body">
                            <ul class="list-unstyled">
                                <li> <b>Order ID:</b> #{{ $checkout->id }}</li>
                                <li> <b>Order Date:</b> {{ date("Y-m-d", strtotime($checkout->created_at)) }}</li>
                                <li> <b>Order Time:</b> {{ date("H:i:s", strtotime($checkout->created_at)) }}</li>
                                <li> <b>Status:</b> {{ str_replace('<br>', ' ', $myfunction->checkout_status($checkout->status)) }}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row" id="invoice-table">
                <div class="col-md-12">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th class="text-center">Color</th>
                                <th class="text-center">Size</th>
                                <th class="text-center">Qtry</th>
                                <th>Price</th>
                                <th class="text-right pr10">Sub total</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach(DB::table('checkout_products')->where('checkout_id', $checkout->id)->get() as $checkout_product)
                            <tr>
                                <td><b>{{ $checkout_product->product_id }}</b></td>
                                <td>{{ DB::table('catalog_products')->where('id', $checkout_product->product_id)->first()->title }}</td>
                                <td class="text-center">{{ DB::table('catalog_attribute_options')->where('id', $checkout_product->color)->first()->store_value }}</td>
                                <td class="text-center">{{ DB::table('catalog_attribute_options')->where('id', $checkout_product->size)->first()->store_value }}</td>
                                <td class="text-center">{{ $checkout_product->qty }}</td>
                                <td>${{ number_format($checkout_product->price, 2) }}</td>
                                <td class="text-right pr10">${{ number_format($checkout_product->sub_total, 2) }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row" id="invoice-footer">
                <div class="col-md-12">
                    <div class="pull-right">
                        <table class="table" id="invoice-summary">
                            <thead>
                                <tr>
                                    <th><b>Total:</b>
                                    </th>
                                    <th>${{ number_format($checkout->total_payment, 2) }}</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                    <div class="clearfix"></div>
                    <div class="panel panel-alt">
                        <div class="panel-heading">
                            <span class="panel-title"> <i class="fa fa-comments-o"></i> Customer comment </span>
                        </div>
                        <div class="panel-body">
                            {{ $checkout->comment }}
                        </div>
                    </div>
                    <br><br>
                    <div class="invoice-buttons pull-right">
                        <a href="javascript:window.print()" class="btn btn-default mr10"><i class="fa fa-print"></i> Print</a>
                    </div>
                    <div class="invoice-buttons">
                        @if ($checkout->status == '1')
                        <button class="btn btn-primary mr10">Pending</button>
                        @else
                        <a class="btn-pending btn btn-default mr10" href="{{ url('admin/manage-orders/change-status/'.$checkout->id.'/pending') }}">Pending</a>
                        @endif
                        @if ($checkout->status == '70')
                        <button class="btn btn-primary mr10">Processing</button>
                        @else
                        <a class="btn-processing btn btn-default mr10" href="{{ url('admin/manage-orders/change-status/'.$checkout->id.'/processing') }}">Processing</a>
                        @endif
                        @if ($checkout->status == '80')
                        <button class="btn btn-primary mr10">Delivering</button>
                        @else
                        <a class="btn-delivering btn btn-default mr10" href="{{ url('admin/manage-orders/change-status/'.$checkout->id.'/delivering') }}">Delivering</a>
                        @endif
                        @if ($checkout->status == '90')
                        <button class="btn btn-primary mr10">Completed</button>
                        @else
                        <a class="btn-completed btn btn-default mr10" href="{{ url('admin/manage-orders/change-status/'.$checkout->id.'/completed') }}">Completed</a>
                        @endif
                        @if ($checkout->status == '11')
                        <button class="btn btn-primary mr10">Canceled</button>
                        @else
                        <a class="btn-canceled btn btn-default" href="{{ url('admin/manage-orders/change-status/'.$checkout->id.'/canceled') }}">Canceled</a>
                        @endif
                    </div>
                </div>
            </div>

        </div>
    </div>

</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript">
    jQuery(document).ready(function() {

        $('.btn-pending').click(function () {
            var x;
            if (confirm("Are you sure? you want to change status to Pending?") == true) {

            } else {
                return false;
            }
        });

        $('.btn-processing').click(function () {
            var x;
            if (confirm("Are you sure? you want to change status to Processing?") == true) {

            } else {
                return false;
            }
        });

        $('.btn-delivering').click(function () {
            var x;
            if (confirm("Are you sure? you want to change status to Delivering?") == true) {

            } else {
                return false;
            }
        });

        $('.btn-completed').click(function () {
            var x;
            if (confirm("Are you sure? you want to change status to Completed?") == true) {

            } else {
                return false;
            }
        });

        $('.btn-canceled').click(function () {
            var x;
            if (confirm("Are you sure? you want to change status to Canceled?") == true) {

            } else {
                return false;
            }
        });

    });
</script>
@endpush
