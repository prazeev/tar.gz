@extends('layouts.admin')

@push('stylesheet')
<link rel="stylesheet" type="text/css" href="{{ url('vendor/plugins/datatables/media/css/dataTables.bootstrap.css') }}">
@endpush

@section('content')
<!-- Start: Topbar -->
<header id="topbar">
    <div class="topbar-left">
        <ol class="breadcrumb">
            <li class="crumb-active">
                <a href="{{ url('admin/manage-orders') }}">Orders</a>
            </li>
            <li class="crumb-icon">
                <a href="{{ url('admin') }}">
                    <span class="glyphicon glyphicon-home"></span>
                </a>
            </li>
            <li class="crumb-trail">Orders</li>
        </ol>
    </div>
    <div class="topbar-right">
        <a class="btn btn-default btn-sm" href="{{ url('admin/manage-orders/download-pending-orders-csv') }}" target="_blank">Download Pending Orders (CSV)</a>
    </div>
</header>
<!-- End: Topbar -->

<!-- Begin: Content -->
<section id="content" class="animated fadeIn">

    @if (Session::has('error-alert'))
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="fa fa-warning pr10"></i> <b>Error:</b> {{ Session::get('error-alert') }}
    </div>
    @elseif (Session::has('success-alert'))
    <div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="fa fa-check pr10"></i> <b>Success:</b> {{ Session::get('success-alert') }}
    </div>
    @endif

    <div class="panel panel-visible" id="spy1">
        <div class="panel-body pn">
            <table class="table table-striped table-hover" id="datatable" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th class="text-center">ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th class="text-center">Option</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach (DB::table('checkouts')->get() as $checkout)
                    <tr>
                        <td class="text-center">{{ $checkout->id }}</td>
                        <td>{{ $checkout->shipping_name }}</td>
                        <td>{{ $checkout->shipping_email }}</td>
                        <td>{{ $checkout->shipping_phone }}</td>
                        <td>${{ number_format($checkout->total_payment, 2) }}</td>
                        <td>{!! $myfunction->checkout_status($checkout->status) !!}</td>
                        <td>{{ $checkout->created_at }}</td>
                        <td class="text-center">
                            <div class="dropdown">
                                <button id="dLabel" class="btn btn-default" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Action
                                    <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dLabel">
                                    <li><a href="{{ url('admin/manage-orders/view-order/'.$checkout->id) }}">View Details</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li class="dropdown-header">CHANGE STATUS</li>
                                    <li><a class="btn-pending" href="{{ url('admin/manage-orders/change-status/'.$checkout->id.'/pending') }}">Pending</a></li>
                                    <li><a class="btn-processing" href="{{ url('admin/manage-orders/change-status/'.$checkout->id.'/processing') }}">Processing</a></li>
                                    <li><a class="btn-delivering" href="{{ url('admin/manage-orders/change-status/'.$checkout->id.'/delivering') }}">Delivering</a></li>
                                    <li><a class="btn-completed" href="{{ url('admin/manage-orders/change-status/'.$checkout->id.'/completed') }}">Completed</a></li>
                                    <li><a class="btn-canceled" href="{{ url('admin/manage-orders/change-status/'.$checkout->id.'/canceled') }}">Canceled</a></li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

</section>
<!-- End: Content -->
@endsection

@push('javascript')
<script type="text/javascript" src="{{ url('vendor/plugins/datatables/media/js/jquery.dataTables.js') }}"></script>
<script type="text/javascript" src="{{ url('vendor/plugins/datatables/media/js/dataTables.bootstrap.js') }}"></script>

<script type="text/javascript">
    jQuery(document).ready(function() {

        // Init tray navigation smooth scroll
        $('.tray-nav a').smoothScroll({
            offset: -145
        });

        // Init Datatables with Tabletools Addon
        $('#datatable').dataTable({
            "order": [ 0, 'desc' ],
            "aoColumnDefs": [{
                'bSortable': false,
                'aTargets': [-1]
            }],
            "iDisplayLength": 10,
            "aLengthMenu": [
            [5, 10, 25, 50, 100, -1],
            [5, 10, 25, 50, 100, "All"]
            ],
            "sDom": '<"dt-panelmenu clearfix"lfr>t<"dt-panelfooter clearfix"ip>',
            "oTableTools": {
                "sSwfPath": "{{ url('vendor/plugins/datatables/extensions/TableTools/swf/copy_csv_xls_pdf.swf') }}"
            }
        });

        $('.btn-pending').click(function () {
            var x;
            if (confirm("Are you sure? you want to change status to Pending?") == true) {

            } else {
                return false;
            }
        });

        $('.btn-processing').click(function () {
            var x;
            if (confirm("Are you sure? you want to change status to Processing?") == true) {

            } else {
                return false;
            }
        });

        $('.btn-delivering').click(function () {
            var x;
            if (confirm("Are you sure? you want to change status to Delivering?") == true) {

            } else {
                return false;
            }
        });

        $('.btn-completed').click(function () {
            var x;
            if (confirm("Are you sure? you want to change status to Completed?") == true) {

            } else {
                return false;
            }
        });

        $('.btn-canceled').click(function () {
            var x;
            if (confirm("Are you sure? you want to change status to Canceled?") == true) {

            } else {
                return false;
            }
        });

    });
</script>
@endpush
