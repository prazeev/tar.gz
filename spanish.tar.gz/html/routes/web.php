<?php

/*
 *  Author: Suson Waiba
 *  Email: susonwaiba@gmail.com
 *  Team: TeamSixOFive
 *  URL: http://teamsixofive.com
 *  Date: September 2016
 */

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/




Route::get('/', 'Site\IndexController@index');



Route::get('/search', 'Site\SearchController@index');




Route::get('/customer', 'Site\Customer\LoginController@index');
Route::get('/customer/login', 'Site\Customer\LoginController@index');
Route::post('/customer/login', 'Site\Customer\LoginController@process');

Route::get('/customer/register', 'Site\Customer\RegisterController@index');
Route::post('/customer/register', 'Site\Customer\RegisterController@process');

Route::get('/customer/logout', 'Site\Customer\LogoutController@index');
Route::get('/customer/forgot-password', 'Site\Customer\ForgotPasswordController@index');
Route::post('/customer/forgot-password', 'Site\Customer\ForgotPasswordController@process');
Route::get('/customer/forgot-password/recover/{email}/{token}', 'Site\Customer\ForgotPasswordController@recover');
Route::post('/customer/forgot-password/recover/{email}/{token}', 'Site\Customer\ForgotPasswordController@recover_process');

Route::get('/customer/account', 'Site\Customer\AccountController@index');
Route::post('/customer/account/process', 'Site\Customer\AccountController@process');
Route::post('/customer/account/change-password', 'Site\Customer\AccountController@change_password');
Route::get('/customer/account/cancel-order/{id}', 'Site\Customer\AccountController@cancel_order');
Route::get('/customer/account/resent-verify-code', 'Site\Customer\AccountController@resent_verify_code');


Route::get('/category/{category_permalink}', 'Site\Catalog\CategoryController@index');
Route::get('/category/{category_permalink}/product/{product_permalink}', 'Site\Catalog\ProductController@index');
Route::post('/category/{category_permalink}/product/{product_permalink}', 'Site\Catalog\ProductController@index');

Route::get('/cart', 'Site\CartController@index');
Route::post('/cart/checkout-process', 'Site\CartController@checkout_process');
Route::get('/cart/checkout', 'Site\CartController@checkout');
Route::get('/cart/empty-cart', 'Site\CartController@empty_cart');
Route::post('/cart/coupon', 'Site\CartController@coupon');

Route::get('/cart/checkout-repay/{id}/{key}', 'Site\CartController@checkout_repay');
Route::get('/cart/checkout-return/{id}/{key}', 'Site\CartController@checkout_return');
Route::get('/cart/checkout-cancel/{id}/{key}', 'Site\CartController@checkout_cancel');

Route::get('/customer/wishlist', 'Site\Customer\WishlistController@index');
Route::get('/customer/wishlist/product/{id}', 'Site\Customer\WishlistController@product');
Route::get('/customer/wishlist/empty_list', 'Site\Customer\WishlistController@empty_list');




Route::post('/review/product/{id}/process', 'Site\ReviewController@process');
Route::post('/review/product/{id}/edit-process', 'Site\ReviewController@edit_process');



Route::get('/verify/account/{email}/{code}', 'Site\VerifyController@account');












Route::get('/admin', 'Admin\IndexController@index');

Route::get('/admin/login', 'Admin\LoginController@index');
Route::post('/admin/login', 'Admin\LoginController@process');

Route::get('/admin/logout', 'Admin\LogoutController@index');




/*Manage Products*/
Route::get('/admin/catalog/manage-products', 'Admin\Catalog\ProductsController@manage');
Route::get('/admin/catalog/manage-products/add-product', 'Admin\Catalog\ProductsController@add');
Route::post('/admin/catalog/manage-products/add-product', 'Admin\Catalog\ProductsController@add_process');

Route::get('/admin/catalog/manage-products/add-simple-product', 'Admin\Catalog\SimpleProductsController@add_simple');
Route::post('/admin/catalog/manage-products/add-simple-product', 'Admin\Catalog\SimpleProductsController@add_simple_process');
Route::get('/admin/catalog/manage-products/edit-simple-product/{id}', 'Admin\Catalog\SimpleProductsController@edit_simple');
Route::post('/admin/catalog/manage-products/edit-simple-product/{id}', 'Admin\Catalog\SimpleProductsController@edit_simple_process');

Route::get('/admin/catalog/manage-products/add-configurable-product', 'Admin\Catalog\ConfigurableProductsController@add_configurable');
Route::post('/admin/catalog/manage-products/add-configurable-product', 'Admin\Catalog\ConfigurableProductsController@add_configurable_process');
Route::get('/admin/catalog/manage-products/edit-configurable-product/{id}', 'Admin\Catalog\ConfigurableProductsController@edit_configurable');
Route::post('/admin/catalog/manage-products/edit-configurable-product/{id}', 'Admin\Catalog\ConfigurableProductsController@edit_configurable_process');

Route::get('/admin/catalog/manage-products/edit-configurable-product/{id}/add-associated-product', 'Admin\Catalog\ConfigurableProductsController@add_associated_product');
Route::post('/admin/catalog/manage-products/edit-configurable-product/{id}/add-associated-product', 'Admin\Catalog\ConfigurableProductsController@add_associated_product_process');

Route::get('/admin/catalog/manage-products/edit-configurable-product/{id}/edit-associated-product/{associated_product_id}', 'Admin\Catalog\ConfigurableProductsController@edit_associated_product');
Route::post('/admin/catalog/manage-products/edit-configurable-product/{id}/edit-associated-product/{associated_product_id}', 'Admin\Catalog\ConfigurableProductsController@edit_associated_product_process');

Route::post('/admin/catalog/manage-products/api', 'Admin\Catalog\ProductsController@api');
Route::get('/admin/catalog/manage-products/{id}/{action}', 'Admin\Catalog\ProductsController@action');
Route::get('/admin/catalog/manage-products/edit-configurable-product/{id}/{associated_product_id}/{action}', 'Admin\Catalog\ProductsController@associated_product_action');


/*Manage Attributes*/
Route::get('/admin/catalog/manage-attributes', 'Admin\Catalog\AttributesController@manage');
Route::get('/admin/catalog/manage-attributes/add-attribute', 'Admin\Catalog\AttributesController@add');
Route::post('/admin/catalog/manage-attributes/add-attribute', 'Admin\Catalog\AttributesController@add_process');
Route::get('/admin/catalog/manage-attributes/edit-attribute/{id}', 'Admin\Catalog\AttributesController@edit');
Route::post('/admin/catalog/manage-attributes/edit-attribute/{id}', 'Admin\Catalog\AttributesController@edit_process');
Route::get('/admin/catalog/manage-attributes/{id}/{action}', 'Admin\Catalog\AttributesController@action');




/*Manage Categories*/
Route::get('/admin/catalog/manage-categories/{id?}/{action?}', 'Admin\Catalog\CategoriesController@manage');
Route::post('/admin/catalog/manage-categories/{id}/process', 'Admin\Catalog\CategoriesController@process');
Route::post('/admin/catalog/manage-categories/api', 'Admin\Catalog\CategoriesController@api');



/*Manage Pages*/
Route::get('/admin/manage-pages', 'Admin\PagesController@manage');
Route::get('/admin/manage-pages/add-page', 'Admin\PagesController@add');
Route::post('/admin/manage-pages/add-page', 'Admin\PagesController@add_process');
Route::get('/admin/manage-pages/edit-page/{id}', 'Admin\PagesController@edit');
Route::post('/admin/manage-pages/edit-page/{id}', 'Admin\PagesController@edit_process');
Route::post('/admin/manage-pages/api', 'Admin\PagesController@api');
Route::get('/admin/manage-pages/{id}/{action}', 'Admin\PagesController@action');

/*Manage Staticblock*/
Route::get('/admin/manage-staticblocks', 'Admin\StaticblocksController@manage');
Route::get('/admin/manage-staticblocks/add-staticblock', 'Admin\StaticblocksController@add');
Route::post('/admin/manage-staticblocks/add-staticblock', 'Admin\StaticblocksController@add_process');
Route::get('/admin/manage-staticblocks/edit-staticblock/{id}', 'Admin\StaticblocksController@edit');
Route::post('/admin/manage-staticblocks/edit-staticblock/{id}', 'Admin\StaticblocksController@edit_process');
Route::post('/admin/manage-staticblocks/api', 'Admin\StaticblocksController@api');
Route::get('/admin/manage-staticblocks/{id}/{action}', 'Admin\StaticblocksController@action');


/*Manage Users*/
Route::get('/admin/manage-users', 'Admin\UsersController@manage');
Route::get('/admin/manage-users/edit-user/{id}', 'Admin\UsersController@edit');
Route::post('/admin/manage-users/edit-user/{id}', 'Admin\UsersController@edit_process');
Route::get('/admin/manage-users/{id}/{action}', 'Admin\UsersController@action');

/*Manage Orders*/
Route::get('/admin/manage-orders', 'Admin\OrdersController@manage');
Route::get('/admin/manage-orders/view-order/{id}', 'Admin\OrdersController@view_order');
Route::get('/admin/manage-orders/change-status/{id}/{status}', 'Admin\OrdersController@change_status');
Route::get('/admin/manage-orders/download-pending-orders-csv', 'Admin\OrdersController@download_pending_orders_csv');



/*Manage Coupons*/
Route::get('/admin/manage-coupons', 'Admin\CouponsController@manage');
Route::get('/admin/manage-coupons/add-coupon', 'Admin\CouponsController@add');
Route::post('/admin/manage-coupons/add-coupon', 'Admin\CouponsController@add_process');
Route::post('/admin/manage-coupons/api', 'Admin\CouponsController@api');
Route::get('/admin/manage-coupons/{id}/{action}', 'Admin\CouponsController@action');





















Route::get('/{permalink}', 'Site\PagesController@index');
