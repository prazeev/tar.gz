define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./gobstones.snippets");
exports.scope = "gobstones";

});
