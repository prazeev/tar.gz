define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./powershell.snippets");
exports.scope = "powershell";

});
