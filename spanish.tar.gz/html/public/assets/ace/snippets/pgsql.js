define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./pgsql.snippets");
exports.scope = "pgsql";

});
