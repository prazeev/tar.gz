define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./matlab.snippets");
exports.scope = "matlab";

});
