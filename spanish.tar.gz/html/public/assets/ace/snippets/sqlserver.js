define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./sqlserver.snippets");
exports.scope = "sqlserver";

});
