define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./_all_modes.snippets");
exports.scope = "_all_modes";

});
