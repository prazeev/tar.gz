define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./ruby.snippets");
exports.scope = "ruby";

});
