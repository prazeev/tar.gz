define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./smarty.snippets");
exports.scope = "smarty";

});
