define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./plain_text.snippets");
exports.scope = "plain_text";

});
