define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./lsl.snippets");
exports.scope = "lsl";

});
