define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./sh.snippets");
exports.scope = "sh";

});
