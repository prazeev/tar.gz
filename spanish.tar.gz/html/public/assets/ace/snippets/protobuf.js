define(function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "protobuf";

});