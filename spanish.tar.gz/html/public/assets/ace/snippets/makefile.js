define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./makefile.snippets");
exports.scope = "makefile";

});
