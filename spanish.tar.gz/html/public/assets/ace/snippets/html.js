define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./html.snippets");
exports.scope = "html";

});
