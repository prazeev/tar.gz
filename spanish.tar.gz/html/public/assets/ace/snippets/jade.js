define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./jade.snippets");
exports.scope = "jade";

});
