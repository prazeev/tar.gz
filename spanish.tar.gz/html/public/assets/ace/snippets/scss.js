define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./scss.snippets");
exports.scope = "scss";

});
