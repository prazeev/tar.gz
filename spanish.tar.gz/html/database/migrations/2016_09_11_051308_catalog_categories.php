<?php

/*
 *  Author: Suson Waiba
 *  Email: susonwaiba@gmail.com
 *  Team: TeamSixOFive
 *  URL: http://teamsixofive.com
 *  Date: September 2016
 */

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CatalogCategories extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('catalog_categories', function (Blueprint $table) {
            $table->increments('id');

            $table->integer('parent')->default('0');

            $table->string('title');
            $table->integer('status')->default('1');
            $table->string('permalink');

            $table->text('description')->nullable();

            $table->string('meta_title')->nullable();
            $table->text('meta_keywords')->nullable();
            $table->text('meta_description')->nullable();
            $table->timestamps();
        });

        DB::table('catalog_categories')->insert([
            'parent' => '0',
            'title' => 'Default Category',
            'permalink' => 'default-category',
            'description' => 'This is default description for default category.',
            'meta_title' => 'This is default meta title for default category.',
            'meta_keywords' => 'This is default meta keywords for default category.',
            'meta_description' => 'This is default meta description for default category.',
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
            ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('catalog_categories');
    }
}
