<?php

/*
 *  Author: Suson Waiba
 *  Email: susonwaiba@gmail.com
 *  Team: TeamSixOFive
 *  URL: http://teamsixofive.com
 *  Date: September 2016
 */

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CatalogProducts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('catalog_products', function (Blueprint $table) {
            $table->increments('id');

            $table->integer('type')->default('1');

            $table->string('title');
            $table->integer('status')->default('1');
            $table->string('permalink');

            $table->text('tagline')->nullable();
            $table->text('description')->nullable();

            $table->string('meta_title')->nullable();
            $table->text('meta_keywords')->nullable();
            $table->text('meta_description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('catalog_products');
    }
}
