		</div>
		<div class="col-md-5">
			<img src="dist/img/ad1.jpg" class="img-responsive">
		</div>
	</div> <!-- end container -->
</main>
<br>
<footer class="palette palette-midnight-blue clearfix">
	<div class="container">
  © <?=date('Y')?> Poll Project
</div>
</footer>

<!-- jQuery (necessary for Flat UI's JavaScript plugins) -->
<script src="dist/js/vendor/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="dist/js/vendor/video.js"></script>
<script src="dist/js/flat-ui.min.js"></script>
<script src="dist/js/script.js"></script>

</body>
</html>